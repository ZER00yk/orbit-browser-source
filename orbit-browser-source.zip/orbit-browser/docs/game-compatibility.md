# Orbit game compatibility — 9 October 2026 (Pacific)

The public catalog and public game-check page contain only entries that passed earlier Orbit play checks or were reported playable on the owner's Chromebook. Catalog entries confirm catalog access, not every game offered by that catalog. Slow loading is labeled. Failed entries, setup-only pages, and the poor-performing flight simulator are absent from both public lists. No previously failed game was promoted in this change.

## Confirmed performance change

The encrypted OPFS reader previously read and decrypted a whole 64 KiB block for every small `File.slice(...).arrayBuffer()` call. The downloaded vel.gg Emscripten module uses that API in `__wasmfs_opfs_read_blob`. Immutable snapshots now reuse their last authenticated block. The existing shared cache remains capped at 32 blocks (2 MiB), is private to the profile runtime, and is wiped on sign-out. Mutable file writers continue to load fresh blocks. Returned slice bytes are copied, so callers cannot modify cached data.

The regression check reads eight adjacent 8 KiB slices with one encrypted block read, verifies the bytes and a block-boundary read, mutates a returned slice, checks another account cannot see the pack, and checks signing out revokes the cached snapshot. Existing atomic writes, truncation, corruption rejection, site separation, worker access, and cookie/session tests also pass. The encrypted file format and saved game data are unchanged.

This is a measured reduction in file-read overhead, not a claim that BO1 now completes a playable session or that network downloads became eight times faster.

## Investigated but still hidden

| Entry | Evidence / remaining limit |
| --- | --- |
| BO1 Zombies | The reported `Pack boot set is missing` error remains unverified after the reader improvement. Previously downloaded loader source was inspected. The actual pinned compiler preserves the worker's map query, and the map module's rewritten syntax passes. A fresh ordinary request to the Kino page returned 403. No alternative origin or access-control bypass was attempted. |
| CS Surf | The published game script, Boreas geometry, and visual manifest were reachable. The geometry and manifest are gzip payloads, which the site's own reader handles. Rewriting the actual game script produced valid module syntax. No complete proxied map play check has passed. |
| WASM Arcade / Grok games / NetQuake | The player reported disappearing pages. The NetQuake HTML has no base element, and the pinned proxy does not inject one, so an injected-base router hypothesis was ruled out. The rewritten published NetQuake bundle passes syntax validation. No runtime root cause or complete gameplay fix was confirmed. |
| Skate 3 / Skate Rust / PES 6 / GTA 5 archive | Remain failed according to the Chromebook report. No verified replacement or playable repair was found. |
| TweetCraft | The world selection page works, but joining times out. No verified connection fix was found. |
| Halo CE / Halo CE mobile / Half-Life-CS / GTA Vice City | Need game files supplied by their player; Vice City also reports an unsupported device. Setup pages do not qualify as playable entries. |
| CloudMoon / Google sign-in / MW2 verification | The sign-in denial and site verification remain unresolved. No provider protections were bypassed. |
| AI flight simulator | The player reported very poor frame rate on Chromebook. It remains absent from the catalog. |

The cloud test browser currently opens Orbit's login page. No new authenticated browser play-through was completed in this change. Retain the hidden status until real in-Orbit gameplay, controls, and any required saving are verified. Do not treat HTTP 200 or a loading screen as a gameplay pass.

Validation: 122 main-app checks and 86 engine checks passed; no failures or skipped tests. The official pinned JavaScript rewriter produced valid modules for the inspected NetQuake, Surfd, and BO1 map sources. These checks do not replace a Chromebook graphics play-through.
