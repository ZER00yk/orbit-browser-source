import { defineConfig } from 'vite';
export default defineConfig({
  server: {
    host:'0.0.0.0',
    allowedHosts:['terminal.local'],
    headers: {
      'Cross-Origin-Opener-Policy':'same-origin',
      'Cross-Origin-Embedder-Policy':'require-corp',
      'Cross-Origin-Resource-Policy':'same-origin'
    },
    proxy:{'/wisp/':{target:'https://wisp.mercurywork.shop',changeOrigin:true,ws:true,rewrite:()=>'/'}},
  },
  build:{target:'es2022',outDir:'dist/client',emptyOutDir:true},
});
