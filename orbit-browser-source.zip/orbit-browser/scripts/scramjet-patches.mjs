// Scramjet 1.1.0's storage proxy reports every requested key as an own
// property, even when getItem returns null. PokéRogue then attempts to
// migrate nonexistent settings and throws in Object.hasOwn(null, ...).
const storageDescriptor='getOwnPropertyDescriptor:(t,r)=>({value:t.getItem(e.url.host+"@"+r),enumerable:!0,configurable:!0,writable:!0})';
const fixedStorageDescriptor='getOwnPropertyDescriptor:(t,r)=>{if("symbol"==typeof r)return Reflect.getOwnPropertyDescriptor(t,r);let n=t.getItem(e.url.host+"@"+r);return null===n?void 0:{value:n,enumerable:!0,configurable:!0,writable:!0}}';

export function patchScramjetStorage(source){
  if(source.split(storageDescriptor).length!==2)throw new Error('The pinned Scramjet storage implementation changed; review its compatibility patch.');
  return source.replace(storageDescriptor,fixedStorageDescriptor);
}

// A loadConfig message can set this.config before the first fetch. Upstream
// treats that as proof of readiness and skips shared config/WASM startup.
// Track readiness separately, including concurrent fetches and failed retries.
const workerLoadConfig='async loadConfig(){if(this.config)return;let e=await (0,l.P2)("$scramjet",1);this.config=await e.get("config","config"),this.config&&((0,c.Nk)(this.config),await (0,s.n$)())}';
const fixedWorkerLoadConfig='async loadConfig(){if(this.orbitEngineReady)return this.orbitEngineReady;return this.orbitEngineReady=(async()=>{let e=await (0,l.P2)("$scramjet",1),t=await e.get("cookies","cookies");t&&this.cookieStore.load(t);this.config??=await e.get("config","config");if(!this.config)throw new Error("Proxy configuration is not ready");(0,c.Nk)(this.config);await (0,s.n$)()})().catch(e=>{this.orbitEngineReady=null;throw e})}';
const workerFetch='async fetch({request:e,clientId:t}){this.config||await this.loadConfig();';
const fixedWorkerFetch='async fetch({request:e,clientId:t}){await this.loadConfig();';
const backgroundCookieLoad='(async()=>{let e=await (0,l.P2)("$scramjet",1),t=await e.get("cookies","cookies");t&&this.cookieStore.load(t)})(),';
const cookieMessage='if("cookie"===e.scramjet$type){this.cookieStore.setCookies';
const cookieDispatch='async dispatch(e,t){let r,n=this.synctoken++,i=new Promise(e=>r=e);return this.syncPool[n]=r,t.scramjet$token=n,e.postMessage(t),await i}';
const fixedCookieDispatch='async dispatch(e,t){let r,o,n=this.synctoken++,i=new Promise(e=>r=e);this.syncPool[n]=e=>{clearTimeout(o);r(e)};t.scramjet$token=n;if("cookie"===t.scramjet$type)o=setTimeout(()=>{delete this.syncPool[n];r()},1500);try{e.postMessage(t);return await i}catch(e){clearTimeout(o);delete this.syncPool[n];throw e}}';
const cookieAck='delete this.syncPool[e.scramjet$token],t(e);return';

export function patchScramjetWorker(source){
  if([workerLoadConfig,workerFetch,backgroundCookieLoad,cookieMessage,cookieDispatch,cookieAck].some(needle=>source.split(needle).length!==2))throw new Error('The pinned Scramjet worker implementation changed; review its startup patch.');
  return source.replace(workerLoadConfig,fixedWorkerLoadConfig).replace(workerFetch,fixedWorkerFetch).replace(backgroundCookieLoad,'').replace(cookieMessage,'if("cookie"===e.scramjet$type){await this.loadConfig();this.cookieStore.setCookies').replace(cookieDispatch,fixedCookieDispatch).replace(cookieAck,'delete this.syncPool[e.scramjet$token],t?.(e);return');
}

// IndexedDB stores a cookie object, not a JSON string. Restoring it must update
// the jar. Response cookies must also reach the page as values (not indices)
// and be persisted even when a page never writes document.cookie itself.
const cookieLoad='load(e){if("object"==typeof e)return e;this.cookies=JSON.parse(e)}';
// Old jars can contain incomplete records from upstream's index messages.
// Retain every valid cookie while preventing a bad record from breaking fetch.
const fixedCookieLoad='load(e){let t;try{t="string"==typeof e?JSON.parse(e):e}catch{return}if(!t||"object"!=typeof t||Array.isArray(t))return;this.cookies={};for(let[e,r]of Object.entries(t))if(r&&"string"==typeof r.name&&"string"==typeof r.value&&"string"==typeof r.domain&&"string"==typeof r.path)this.cookies[e]=r}';
const pageCookieAck='e.serviceWorker.controller.postMessage(r)';
const fixedPageCookieAck='(()=>{let t=e.descriptors.get("ServiceWorkerContainer.prototype.controller",e.serviceWorker);t&&e.natives.call("ServiceWorker.prototype.postMessage",t,r)})()';
const cookieDomain='e.hostname.endsWith(a.domain.slice(1))';
const responseModule='5790:function(e,t,r){r.d(t,{Pf:()=>m,V3:()=>S,dT:()=>w});';
const responseCookies='let x=v["set-cookie"]||[];for(let t in x)if(h){let r=f.dispatch(h,{scramjet$type:"cookie",cookie:t,url:e.href});"document"!==n&&"iframe"!==n&&await r}for(let t in await d.setCookies(x instanceof Array?x:[x],e),v)';
const fixedResponseCookies='let x=v["set-cookie"]||[];x=Array.isArray(x)?x:[x];if(x.length){await d.setCookies(x,e);let orbitDB;try{orbitDB=await orbitCookieDB.P2("$scramjet",1);await orbitDB.put("cookies",JSON.parse(d.dump()),"cookies")}catch{console.warn("Orbit could not persist website cookies")}finally{orbitDB?.close?.()}for(let t of x)if(h){let r=f.dispatch(h,{scramjet$type:"cookie",cookie:t,url:e.href}).catch(()=>{});"document"!==n&&"iframe"!==n&&await r}}for(let t in v)';

export function patchScramjetCookies(source){
  if([cookieLoad,cookieDomain,responseModule,responseCookies,pageCookieAck].some(needle=>source.split(needle).length!==2))throw new Error('The pinned Scramjet cookie implementation changed; review its session patch.');
  return source.replace(cookieLoad,fixedCookieLoad).replace(cookieDomain,'(e.hostname===a.domain.slice(1)||e.hostname.endsWith(a.domain))').replace(responseModule,'5790:function(e,t,r){const orbitCookieDB=r(6570);r.d(t,{Pf:()=>m,V3:()=>S,dT:()=>w});').replace(responseCookies,fixedResponseCookies).replace(pageCookieAck,fixedPageCookieAck);
}
