import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {webcrypto} from 'node:crypto';

// Run the shipped WASM transport as a worker, without a simulated browser UI.
export async function loadTransport({WebSocket,fetch,instantiateDelay=0,sharedMemory=true}={}){
  if(!vm.SourceTextModule)throw new Error('Run with --experimental-vm-modules.');
  class CloseEvent extends Event {constructor(type,options={}){super(type);Object.assign(this,{code:options.code||0,reason:options.reason||''});}}
  const intervals=new Set(),timers=new Set();
  const globals={
    console,URL,URLSearchParams,Event,EventTarget,MessageEvent,CustomEvent,CloseEvent,DOMException,
    AbortController,AbortSignal,Headers,Request,Response,ReadableStream,WritableStream,
    TransformStream,TextEncoder,TextDecoder,Blob,atob,btoa,
    setTimeout:(callback,delay)=>{const timer=setTimeout(()=>{timers.delete(timer);callback();},delay);timers.add(timer);return timer;},
    clearTimeout:timer=>{timers.delete(timer);clearTimeout(timer);},
    setInterval:(callback,delay)=>{const timer=setInterval(callback,delay);intervals.add(timer);return timer;},
    clearInterval:timer=>{intervals.delete(timer);clearInterval(timer);},queueMicrotask,performance,crypto:webcrypto,
    WebSocket:WebSocket||class{constructor(){throw new Error('Unexpected network connection in startup test.');}},
    // Emscripten may fetch its embedded data: WASM when fetch is available.
    fetch:(url,options)=>String(url).startsWith('data:')?globalThis.fetch(url,options):fetch?fetch(url,options):Promise.reject(new Error('Unexpected DNS request in transport test.')),
    importScripts(){},location:{href:'https://orbit.example/baremux/worker.js'},
    navigator:{userAgent:'Mozilla/5.0 Chrome/154.0.0.0 Safari/537.36'},
  };
  const context=vm.createContext(globals);context.self=context;
  if(!sharedMemory)vm.runInContext('globalThis.SharedArrayBuffer=undefined;globalThis.crossOriginIsolated=false;',context);
  if(instantiateDelay){context.instantiateDelay=instantiateDelay;vm.runInContext(`{
    const instantiate=WebAssembly.instantiate;
    WebAssembly.instantiate=(...args)=>new Promise(resolve=>setTimeout(resolve,instantiateDelay)).then(()=>instantiate(...args));
  }`,context);}
  const curl=new vm.SourceTextModule(await readFile(new URL('../public/libcurl/index.mjs',import.meta.url),'utf8'),{context});
  const policy=new vm.SourceTextModule(await readFile(new URL('../public/dns-policy.mjs',import.meta.url),'utf8'),{context});
  const dns=new vm.SourceTextModule(await readFile(new URL('../public/wisp-dns.mjs',import.meta.url),'utf8'),{context});
  const adapter=new vm.SourceTextModule(await readFile(new URL('../public/transport.mjs',import.meta.url),'utf8'),{context});
  await curl.link(()=>{throw new Error('Unexpected transport dependency.');});
  await policy.link(()=>{throw new Error('Unexpected DNS policy dependency.');});
  await dns.link(specifier=>{if(specifier!=='./dns-policy.mjs?v=1')throw new Error('Unexpected DNS adapter dependency.');return policy;});
  await adapter.link(specifier=>{if(specifier==='./libcurl/index.mjs?v=2.0.5-orbit.1')return curl;if(specifier==='./wisp-dns.mjs?v=1')return dns;throw new Error('Unexpected adapter dependency.');});
  await adapter.evaluate();
  const Transport=adapter.namespace.default;
  Transport.disposeHarness=()=>{for(const timer of intervals)clearInterval(timer);for(const timer of timers)clearTimeout(timer);intervals.clear();timers.clear();};
  return Transport;
}
