// Export the already bundled API so Orbit can adapt TCP destination lookup
// without changing curl's TLS implementation or certificate verification.
export function patchLibcurlExports(source){
  const exports='export {\n  LibcurlClient,\n  LibcurlClient as default\n};';
  if(!source.endsWith(exports+'\n'))throw new Error('Pinned libcurl exports changed; review the DNS adapter before vendoring.');
  return source.slice(0,-exports.length-1)+exports.replace('  LibcurlClient,','  libcurl,\n  LibcurlClient,')+'\n';
}
