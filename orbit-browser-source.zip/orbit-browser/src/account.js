import {gcm} from '@noble/ciphers/aes.js';
const nativeStorage=window.localStorage,encoder=new TextEncoder(),decoder=new TextDecoder();
const b64=bytes=>{let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s).replaceAll('+','-').replaceAll('/','_').replace(/=+$/,'');};
const unb64=value=>Uint8Array.from(atob(value.replaceAll('-','+').replaceAll('_','/')),x=>x.charCodeAt(0));
let account=null,values={},key=null,changedAt=0,saveTimer,saveChain=Promise.resolve();
const channel=typeof BroadcastChannel==='function'?new BroadcastChannel('orbit-account'):null;
export async function api(path,method='GET',data){
  const response=await fetch('/api/'+path,{method,credentials:'same-origin',cache:'no-store',headers:data?{'Content-Type':'application/json'}:{},body:data?JSON.stringify(data):undefined});
  let body;try{body=await response.json();}catch{body={error:'Orbit is temporarily unavailable.'};}
  if(!response.ok)throw Object.assign(new Error(body.error||'Please sign in again.'),{status:response.status});return body;
}
function pack(){const nonce=crypto.getRandomValues(new Uint8Array(12)),cipher=gcm(key,nonce,encoder.encode('orbit-app:'+account.id)).encrypt(encoder.encode(JSON.stringify({values,changedAt})));return 'v1.'+b64(new Uint8Array([...nonce,...cipher]));}
function unpack(value){const bytes=unb64(value.slice(3));return JSON.parse(decoder.decode(gcm(key,bytes.slice(0,12),encoder.encode('orbit-app:'+account.id)).decrypt(bytes.slice(12))));}
export function currentAccount(){return account;}
export const accountStorage={getItem:name=>Object.hasOwn(values,name)?values[name]:null,setItem(name,value){values[name]=String(value);scheduleSave();},removeItem(name){delete values[name];scheduleSave();},clear(){values={};scheduleSave();}};
function scheduleSave(){changedAt=Date.now();const cipher=pack();nativeStorage.setItem('orbit.profile.'+account.id,JSON.stringify({cipher,changedAt}));clearTimeout(saveTimer);saveTimer=setTimeout(()=>flush().catch(()=>{}),500);}
export async function flush(){
  if(!account||!key)return;clearTimeout(saveTimer);const cipher=pack(),stamp=changedAt;
  saveChain=saveChain.catch(()=>{}).then(async()=>{
    try{await api('profile','PUT',{cipher,userId:account.id});document.getElementById('profile-sync').textContent='Profile saved';}
    catch(error){document.getElementById('profile-sync').textContent='Saved on this device · cloud save pending';if([401,409].includes(error.status))lock();else saveTimer=setTimeout(()=>flush().catch(()=>{}),5000);throw error;}
  });return saveChain;
}
function lock(){key=null;values={};document.getElementById('frames').replaceChildren();location.reload();}
window.addEventListener('orbit-account-expired',lock);
channel?.addEventListener('message',event=>{if(event.data?.type==='logout'||(account&&event.data?.id!==account.id))lock();});
window.addEventListener('pagehide',()=>{if(account&&key){try{fetch('/api/profile',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify({cipher:pack(),userId:account.id}),keepalive:true}).catch(()=>{});}catch{}}});
export async function logout(){await flush();await api('logout','POST',{});channel?.postMessage({type:'logout'});lock();}
export async function initialiseAccount(){
  const panel=document.getElementById('account-gate'),form=document.getElementById('account-form'),message=document.getElementById('account-message');
  const fragment=new URLSearchParams(location.hash.slice(1));let code=fragment.get('setup')||fragment.get('invite'),action=fragment.has('setup')?'setup':fragment.has('invite')?'register':'login';
  const heading=document.getElementById('account-heading'),hint=document.getElementById('account-hint');
  const existing=document.getElementById('account-existing');
  const renderGate=()=>{
    heading.textContent=action==='setup'?'Create your owner account':action==='register'?'Create your Orbit account':'Welcome to Orbit';
    hint.textContent=action==='login'?'Sign in with your Orbit username and password. Ask the owner for an invitation to join.':action==='register'?'You’re invited. Choose a new username and a password or passphrase of at least 15 characters. This creates your own private account.':'Choose your own username and a password or passphrase of at least 15 characters.';
    document.getElementById('account-password').autocomplete=action==='login'?'current-password':'new-password';
    document.getElementById('account-submit').textContent=action==='login'?'Sign in':'Create account';
    existing.hidden=true;
  };
  renderGate();
  const loggedOut=()=>{panel.hidden=false;document.getElementById('app').hidden=true;document.getElementById('account-username').focus();};
  const activate=async result=>{
    const profile=await api('profile');account={...result.user,engine:result.engine};key=unb64(result.key);values={};
    let saved=null;if(profile.cipher){try{saved=unpack(profile.cipher);}catch{throw new Error('Your profile couldn’t be read. Please try again.');}}
    try{const local=JSON.parse(nativeStorage.getItem('orbit.profile.'+account.id)||'null');if(local){const recovered=unpack(local.cipher);if(!saved||recovered.changedAt>saved.changedAt)saved=recovered;}}catch{}
    if(saved&&saved.values&&typeof saved.values==='object'){values=saved.values;changedAt=saved.changedAt||0;}
    else if(account.role==='owner'){
      for(const name of ['orbit.browsing.v1','orbit.preferences.v1']){const value=nativeStorage.getItem(name);if(value!==null)values[name]=value;}
    }
    panel.hidden=true;document.getElementById('app').hidden=false;document.getElementById('account-name').textContent=account.username;
    document.getElementById('profile-sync').textContent='Profile saved';document.getElementById('invite-section').hidden=account.role!=='owner';
    channel?.postMessage({type:'signed-in',id:account.id});
    document.getElementById('sign-out').onclick=async()=>{try{await logout();}catch(error){document.getElementById('account-status').textContent=error.message;}};
    document.getElementById('create-invite').onclick=async()=>{const button=document.getElementById('create-invite');button.disabled=true;try{const invite=await api('invites','POST',{});document.getElementById('invite-link').value=invite.url;document.getElementById('invite-result').hidden=false;}catch(error){document.getElementById('account-status').textContent=error.message;}finally{button.disabled=false;}};
    document.getElementById('copy-invite').onclick=async()=>{try{await navigator.clipboard.writeText(document.getElementById('invite-link').value);document.getElementById('account-status').textContent='Invitation copied.';}catch{document.getElementById('invite-link').select();}};
    document.getElementById('password-form').onsubmit=async event=>{event.preventDefault();const button=document.getElementById('save-password');button.disabled=true;try{await api('password','POST',{currentPassword:document.getElementById('current-password').value,password:document.getElementById('new-password').value});event.target.reset();document.getElementById('account-status').textContent='Password updated. Other sessions were signed out.';}catch(error){document.getElementById('account-status').textContent=error.message;}finally{button.disabled=false;}};
    await import('./main.js');await flush();
  };
  form.onsubmit=async event=>{event.preventDefault();const button=document.getElementById('account-submit');button.disabled=true;message.textContent='';try{
    await api(action,'POST',{username:document.getElementById('account-username').value,password:document.getElementById('account-password').value,remember:document.getElementById('remember-account').checked,code});
    // Fragments are not sent to the server. Keep the invitation in the URL
    // through refreshes and failed attempts; remove it only after it is used.
    if(action!=='login'){fragment.delete('setup');fragment.delete('invite');const remaining=fragment.toString();history.replaceState(null,'',location.pathname+location.search+(remaining?'#'+remaining:''));action='login';code=null;renderGate();}
    document.getElementById('account-password').value='';await activate(await api('account'));
  }catch(error){message.textContent=error.message;}finally{button.disabled=false;}};
  if(action!=='login'){
    loggedOut();
    try{const result=await api('account');if(result.user){document.getElementById('account-existing-name').textContent=result.user.username;existing.hidden=false;}}
    catch(error){if(error.status!==401)message.textContent=error.message;}
    return;
  }
  try{await activate(await api('account'));}catch(error){loggedOut();if(error.status!==401)message.textContent=error.message;}
}
