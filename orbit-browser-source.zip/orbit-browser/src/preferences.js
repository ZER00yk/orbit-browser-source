export const PREFERENCES_KEY='orbit.preferences.v1';
export const DEFAULT_PREFERENCES={theme:'dark',compact:false,showBookmarks:true,showStatus:true,reducedMotion:false,saveHistory:true,restoreTabs:true,adblock:true,allowedSites:[]};
export function loadPreferences(storage){
  const result={...DEFAULT_PREFERENCES,allowedSites:[]};
  try{
    const saved=JSON.parse(storage.getItem(PREFERENCES_KEY));
    if(!saved||typeof saved!=='object')return result;
    if(['dark','light'].includes(saved.theme))result.theme=saved.theme;
    for(const key of ['compact','showBookmarks','showStatus','reducedMotion','saveHistory','restoreTabs','adblock'])if(typeof saved[key]==='boolean')result[key]=saved[key];
    if(Array.isArray(saved.allowedSites))result.allowedSites=[...new Set(saved.allowedSites.filter(host=>typeof host==='string'&&/^(?:[a-z0-9-]+\.)+[a-z0-9-]+$/i.test(host)).map(host=>host.toLowerCase()))].slice(0,80);
  }catch{}
  return result;
}
