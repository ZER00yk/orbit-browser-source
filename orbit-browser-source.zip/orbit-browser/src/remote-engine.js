import {api,currentAccount} from './account.js';
import {migrateOwner} from './legacy.js';
export class RemoteController extends EventTarget{
  constructor(){super();this.frames=new Set();this.policy={};}
  async init(){return this;}
  async modifyConfig(config){this.policy=config;for(const frame of this.frames)frame.send({type:'policy',config});}
  createFrame(){const frame=new RemoteFrame(this);this.frames.add(frame);return frame;}
  async check(){const frame=this.createFrame();frame.frame.hidden=true;document.body.append(frame.frame);try{await frame.ready;await frame.migration;return await frame.command('check');}finally{frame.destroy();}}
}
class RemoteFrame extends EventTarget{
  constructor(controller){
    super();this.controller=controller;this.origin=currentAccount().engine;this.channel=crypto.randomUUID();this.frame=document.createElement('iframe');this.frame.src=this.origin+'/api/runtime/#'+this.channel;this.frame.setAttribute('allow','cross-origin-isolated');this.frame.referrerPolicy='no-referrer';this.frame.title='Orbit browsing profile';this.pending=new Map();this.counter=0;
    this.ready=new Promise((resolve,reject)=>{this.resolveReady=resolve;this.rejectReady=reject;this.timer=setTimeout(()=>this.fail(new Error('The browsing profile couldn’t start. Please reload Orbit.')),25000);});
    this.listener=async event=>{
      if(event.origin!==this.origin||event.source!==this.frame.contentWindow||event.data?.channel!==this.channel)return;
      const data=event.data;
      if(data.type==='ready'){try{const {ticket}=await api('engine-ticket','POST',{});this.send({type:'init',ticket,config:controller.policy});}catch(error){this.fail(error);}}
      if(data.type==='started'){clearTimeout(this.timer);this.started=true;this.resolveReady();this.migration=migrateOwner(this);this.migration.catch(error=>this.dispatchEvent(Object.assign(new Event('error'),{message:'Existing game data could not be copied yet: '+error.message})));}
      if(data.type==='error')this.fail(new Error(data.message||'The browsing profile couldn’t start.'));
      if(data.type==='reply'){const pending=this.pending.get(data.id);if(pending){this.pending.delete(data.id);clearTimeout(pending.timer);data.error?pending.reject(new Error(data.error)):pending.resolve(data.result);}}
      if(data.type==='navigate'||data.type==='urlchange'||data.type==='open-tab')this.dispatchEvent(Object.assign(new Event(data.type),{url:data.url}));
      if(data.type==='loaded'){this.title=data.title;this.hasLoaded=true;this.frame.dispatchEvent(new Event('load'));}
      if(data.type==='diagnostics')window.__orbitGameDiagnostics?.(this.frame.contentWindow,data.report);
      if(data.type==='notice')window.dispatchEvent(new CustomEvent('orbit-engine-notice',{detail:data.notice}));
      if(data.type==='key')document.dispatchEvent(new KeyboardEvent('keydown',data.key));
      if(data.type==='renew-session')this.refreshSession();
      if(data.type==='session-expired'){document.getElementById('frames').replaceChildren();location.reload();}
    };
    window.addEventListener('message',this.listener);
    this.refresh=setInterval(()=>{if(!this.frame.isConnected){this.destroy();return;}this.refreshSession();},4*60000);
    this.resume=()=>{if(document.visibilityState!=='hidden')this.refreshSession();};
    document.addEventListener('visibilitychange',this.resume);window.addEventListener('pageshow',this.resume);
    // Remove event listeners when a tab is closed, not only on the next refresh.
    this.observer=new MutationObserver(()=>{if(this.wasMounted&&!this.frame.isConnected)this.destroy();if(this.frame.isConnected)this.wasMounted=true;});this.observer.observe(document.body,{childList:true,subtree:true});
  }
  async refreshSession(){
    if(!this.started||this.destroyed||this.renewing)return;
    this.renewing=true;
    try{const {ticket}=await api('engine-ticket','POST',{});if(!this.destroyed)this.send({type:'refresh',ticket});}
    catch(error){if(error.status===401){this.send({type:'stop'});window.dispatchEvent(new Event('orbit-account-expired'));}}
    finally{this.renewing=false;}
  }
  fail(error){clearTimeout(this.timer);if(!this.started)this.failed=true;this.rejectReady(error);this.dispatchEvent(Object.assign(new Event('error'),{message:error.message}));}
  send(data){this.frame.contentWindow?.postMessage({...data,channel:this.channel},this.origin);}
  async command(type,data={}){await this.ready;const id=++this.counter;return new Promise((resolve,reject)=>{const timer=setTimeout(()=>{this.pending.delete(id);reject(new Error('The browsing profile did not respond.'));},20000);this.pending.set(id,{resolve,reject,timer});this.send({type,id,...data});});}
  go(url){this.hasLoaded=false;this.ready.then(async()=>{await this.migration;this.send({type:'go',url});}).catch(()=>{});}
  reload(){this.send({type:'reload'});}
  destroy(){this.destroyed=true;this.send({type:'stop'});clearTimeout(this.timer);clearInterval(this.refresh);window.removeEventListener('message',this.listener);document.removeEventListener('visibilitychange',this.resume);window.removeEventListener('pageshow',this.resume);this.observer.disconnect();this.frame.remove();this.controller.frames.delete(this);for(const p of this.pending.values()){clearTimeout(p.timer);p.reject(new Error('This tab was closed.'));}this.pending.clear();}
}
