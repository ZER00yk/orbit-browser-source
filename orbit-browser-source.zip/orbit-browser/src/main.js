import './style.css';
import {STORAGE_KEY,restoreState,freshState,resolveAddress,recordVisit,validUrl,validRelay} from './model.js';
import {accountStorage as localStorage} from './account.js';
import {RemoteController} from './remote-engine.js';
import {sanitizeDiagnostics} from '../server/game-diagnostics.mjs';
import {PREFERENCES_KEY,loadPreferences} from './preferences.js';
import {verifiedGames} from './games.js';

const $=id=>document?.getElementById(id);
const paths={back:'m12 4-8 8 8 8M4 12h17',forward:'m12 4 8 8-8 8M20 12H3',reload:'M20 7v5h-5M20 12a8 8 0 1 0-2 6M20 7l-3-3',home:'m3 10 9-7 9 7M5 9v11h5v-6h4v6h5V9',search:'M10.5 18a7.5 7.5 0 1 0 0-15 7.5 7.5 0 0 0 0 15M16 16l5 5',star:'m12 3 2.8 5.7 6.2.9-4.5 4.4 1.1 6.2L12 17.3l-5.6 2.9 1.1-6.2L3 9.6l6.2-.9Z',history:'M3 4v5h5M3 9a9 9 0 1 1 0 6M12 7v5l3 2',settings:'M9 3h6l1 3 3 1 2 5-2 5-3 1-1 3H9l-1-3-3-1-2-5 2-5 3-1ZM15 12a3 3 0 1 1-6 0 3 3 0 0 1 6 0',close:'m6 6 12 12M18 6 6 18',globe:'M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0M3 12h18M12 3c-4 5-4 13 0 18M12 3c4 5 4 13 0 18'};
Object.assign(paths,{fullscreen:'M8 3H3v5M16 3h5v5M3 16v5h5M21 16v5h-5',restore:'M3 8h5V3M21 8h-5V3M8 21v-5H3M16 21v-5h5',shield:'m12 3 8 3v6c0 5-8 9-8 9s-8-4-8-9V6ZM8 12l3 3 5-6'});
function icon(name){return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="${paths[name]||paths.globe}"/></svg>`;}
for(const id of ['back','forward','reload','home'])$(id).innerHTML=icon(id);
$('bookmark-page').innerHTML=icon('star');$('history-button').innerHTML=icon('history');$('settings-button').innerHTML=icon('settings');$('address-icon').innerHTML=icon('globe');$('home-search-icon').innerHTML=icon('search');
$('fullscreen-button').innerHTML=icon('fullscreen');$('restore-controls').innerHTML=icon('restore');$('adblock-button').innerHTML=icon('shield');
document.querySelectorAll('[data-close]').forEach(button=>{button.innerHTML=icon('close');button.onclick=()=>$(button.dataset.close).close();});

const preferences=loadPreferences(localStorage);
let state=restoreState(localStorage);
if(!preferences.restoreTabs){state.tabs=freshState().tabs;state.activeId=null;}
if(!state.tabs.some(tab=>tab.id===state.activeId))state.activeId=state.tabs[0].id;
const runtime=new Map();
window.__orbitGameDiagnostics=(source,input)=>{
  const entry=Array.from(runtime.entries()).find(([,view])=>view.frame.frame.contentWindow===source);
  if(!entry)return;
  const [id,view]=entry,tab=state.tabs.find(value=>value.id===id);
  if(!tab||!validUrl(tab.url)||new URL(tab.url).hostname!=='pokerogue.net')return;
  const report=sanitizeDiagnostics(input);if(!report)return;
  view.gameDetails=report;
  if(id===state.activeId)renderGameDetails();
  // Only public asset names, loader counts, and redacted errors are reported.
  // No cookies, tokens, saved games, or browsing history enter this endpoint.
  const signature=JSON.stringify(report);
  view.diagnosticSignatures||=new Set();
  if(view.diagnosticSignatures.size<8&&!view.diagnosticSignatures.has(signature)){
    view.diagnosticSignatures.add(signature);
    fetch('/api/game-diagnostics',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',body:signature}).catch(()=>{});
  }
};
const pendingFrames=new Map(),navigationVersions=new Map();
let enginePromise=null,controller=null,connection=null,connectionState='checking',connectionMessage='',checkPromise=null,toastTimer,sharedRelay=true;
let controlsHidden=false;const blockedCounts=new Map();
function active(){return state.tabs.find(tab=>tab.id===state.activeId);}
function persist(){try{const saved=preferences.restoreTabs?state:{...state,tabs:[],activeId:null};localStorage.setItem(STORAGE_KEY,JSON.stringify(saved));}catch{notify('This browser couldn’t save your browsing data.');}}
function notify(message){$('toast').textContent=message;$('toast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('toast').hidden=true,4000);}
function currentHost(){try{return new URL(active().url).hostname;}catch{return '';}}
function blockingPolicy(){return {enabled:preferences.adblock,allowedSites:[...preferences.allowedSites]};}
async function syncBlocking(){if(controller?.modifyConfig)await controller.modifyConfig({orbitAdblock:blockingPolicy(),orbitRelay:state.relay});}
function savePreferences(){
  try{localStorage.setItem(PREFERENCES_KEY,JSON.stringify(preferences));}catch{notify('Your settings couldn’t be saved on this device.');}
  applyPreferences();persist();
}
function applyPreferences(){
  document.documentElement.dataset.theme=preferences.theme;
  document.documentElement.dataset.motion=preferences.reducedMotion?'reduced':'normal';
  document.querySelector('meta[name="theme-color"]').content=preferences.theme==='dark'?'#181b22':'#f7f9fb';
  $('app').classList.toggle('compact',preferences.compact);
  $('bookmark-bar').hidden=!preferences.showBookmarks;
  document.querySelector('.statusbar').hidden=!preferences.showStatus;
  $('theme').value=preferences.theme;
  for(const [id,key]of [['compact-toolbar','compact'],['show-bookmarks','showBookmarks'],['show-status','showStatus'],['reduced-motion','reducedMotion'],['save-history','saveHistory'],['restore-tabs','restoreTabs'],['adblock-enabled','adblock']])$(id).checked=preferences[key];
  renderBlocking();
}
function renderBlocking(){
  const host=currentHost(),allowed=host&&preferences.allowedSites.includes(host),enabled=preferences.adblock&&!allowed,count=blockedCounts.get(host)||0;
  $('adblock-button').classList.toggle('enabled',enabled);
  $('adblock-button').title=preferences.adblock?(allowed?'Ad blocking paused for this website':`Ad blocker on · ${count} blocked`):'Ad blocker off';
  $('adblock-button').setAttribute('aria-label',$('adblock-button').title+'. Open settings');
  $('site-ads').disabled=!host||!preferences.adblock;$('site-ads').checked=!!allowed;
  $('site-ads-label').textContent=host?`Allow ads on ${host}`:'Allow ads on this website';
  $('adblock-exceptions').replaceChildren();
  for(const site of preferences.allowedSites){
    const row=textNode('div','exception-row',''),button=textNode('button','text-button','Remove');row.append(textNode('span','',site),button);
    button.type='button';button.setAttribute('aria-label',`Resume ad blocking on ${site}`);
    button.onclick=()=>{preferences.allowedSites=preferences.allowedSites.filter(value=>value!==site);savePreferences();syncBlocking().catch(()=>notify('Reload Orbit to update ad blocking.'));};
    $('adblock-exceptions').append(row);
  }
}
async function setFullscreen(hidden){
  controlsHidden=hidden;$('app').classList.toggle('controls-hidden',hidden);$('restore-controls').hidden=!hidden;
  $('fullscreen-button').setAttribute('aria-pressed',String(hidden));
  if(hidden){
    try{if(!document.fullscreenElement&&document.documentElement.requestFullscreen)await document.documentElement.requestFullscreen({navigationUI:'hide'});}catch{notify('Controls hidden. Use the corner button to restore them.');}
    (runtime.get(state.activeId)?.frame.frame||$('restore-controls')).focus();
  }else{
    try{if(document.fullscreenElement===document.documentElement)await document.exitFullscreen();}catch{}
    $('fullscreen-button').focus();
  }
}
function fullscreenKeys(event){
  if((event.ctrlKey||event.metaKey)&&event.shiftKey&&event.key.toLowerCase()==='f'){event.preventDefault();setFullscreen(!controlsHidden);return true;}
  if(event.key==='Escape'&&controlsHidden){event.preventDefault();setFullscreen(false);return true;}
  return false;
}
function browserKeys(event){
  if(fullscreenKeys(event))return;
  if((event.ctrlKey||event.metaKey)&&event.key.toLowerCase()==='k'){
    event.preventDefault();const focusAddress=()=>{$('address').focus();$('address').select();};
    if(controlsHidden)setFullscreen(false).then(focusAddress);else focusAddress();
  }
  if(event.altKey&&['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();navigateHistory(event.key==='ArrowLeft'?-1:1);}
}
document.addEventListener('fullscreenchange',()=>{if(controlsHidden&&!document.fullscreenElement)setFullscreen(false);});
window.addEventListener('orbit-engine-notice',event=>{
  event={data:event.detail};
  if(typeof event.data?.site!=='string')return;
  if(['orbit-site-challenge','orbit-youtube-restricted','orbit-roblox-recovery-blocked','orbit-google-signin','orbit-google-denied'].includes(event.data.type)){
    for(const [id,view]of runtime){const tab=state.tabs.find(value=>value.id===id);if(!tab?.url)continue;const host=new URL(tab.url).hostname;const matches=['orbit-google-signin','orbit-google-denied'].includes(event.data.type)?id===state.activeId:host===event.data.site||host.endsWith('.'+event.data.site);if(matches){view.siteIssue=event.data.type;view.noticeDismissed=false;}}
    renderSiteNotice();return;
  }
  if(event.data.type!=='orbit-adblock-blocked')return;
  blockedCounts.set(event.data.site,(blockedCounts.get(event.data.site)||0)+1);renderBlocking();
});
function renderSiteNotice(){
  const tab=active(),view=runtime.get(tab.id);
  const messages={
    'orbit-site-challenge':'This website’s Cloudflare check is preventing it from opening in this Orbit tab.',
    'orbit-youtube-restricted':'YouTube is asking you to sign in to confirm you’re not a bot. Video playback may remain unavailable through this connection.',
    'orbit-roblox-recovery-blocked':'Roblox’s security check is blocking account recovery in this Orbit tab.',
    'orbit-google-signin':'Google sign-in is not finishing in this Orbit tab. Some sign-in providers restrict embedded browsers.',
    'orbit-google-denied':'Google denied this sign-in request (403). Use this service’s email or username sign-in if it offers one.',
  };
  const kind=view?.siteIssue;
  $('site-notice').hidden=!tab.url||!view||view.noticeDismissed||!messages[kind];
  $('site-notice-message').textContent=messages[kind]||'';
}
function getRelay(){return state.relay || `${location.protocol==='https:'?'wss:':'ws:'}//${location.host}/wisp/`;}
function setConnection(value,message){connectionState=value;connectionMessage=message;const node=$('connection-status');if(!node)return;node.dataset.state=value;node.textContent=value==='connected'?'Connection ready':value==='checking'?'Checking connection':'Connection unavailable';$('connection-detail').textContent=message;}
function checkConnection(){
  if(checkPromise)return checkPromise;setConnection('checking','Checking your browsing connection.');
  checkPromise=(async()=>{try{const engine=await ensureEngine(),ok=await engine.check();setConnection(ok?'connected':'error',ok?'Connected to your isolated browsing profile.':'The browsing relay is unavailable. Try again.');return ok;}catch(error){setConnection('error',error.message);return false;}finally{checkPromise=null;}})();return checkPromise;
}
async function ensureEngine(){
  if(!enginePromise)enginePromise=(async()=>{controller=new RemoteController();await controller.init();await syncBlocking();return controller;})().catch(error=>{enginePromise=null;throw error;});return enginePromise;
}

function textNode(tag,className,text){const node=document.createElement(tag);node.className=className;node.textContent=text;return node;}
function timeLabel(time){const elapsed=Date.now()-time;return elapsed<60000?'Just now':elapsed<3600000?`${Math.floor(elapsed/60000)}m ago`:elapsed<86400000?`${Math.floor(elapsed/3600000)}h ago`:new Date(time).toLocaleDateString(undefined,{month:'short',day:'numeric'});}
function historyRow(entry){
  const row=document.createElement('button');row.type='button';row.className='recent-row';row.title=entry.url;row.append(textNode('span','site-letter',new URL(entry.url).hostname.replace(/^www\./,'')[0].toUpperCase()));const info=textNode('span','recent-info','');info.append(textNode('span','recent-title',entry.title),textNode('span','recent-domain',new URL(entry.url).hostname));row.append(info,textNode('span','recent-date',timeLabel(entry.time)));row.onclick=()=>{$('history-dialog').close();navigate(entry.url);};return row;
}
function renderTabs(){
  const tabs=$('tabs');tabs.replaceChildren();
  state.tabs.forEach((tab,index)=>{
    const node=document.createElement('div');node.className='tab';node.setAttribute('role','tab');node.setAttribute('aria-selected',String(tab.id===state.activeId));node.setAttribute('aria-controls',`frame-${tab.id}`);node.tabIndex=tab.id===state.activeId?0:-1;node.title=tab.url||'New tab';node.append(textNode('span','tab-mark',''),textNode('span','tab-label',tab.title));const close=document.createElement('button');close.className='tab-close';close.setAttribute('aria-label',`Close ${tab.title}`);close.innerHTML=icon('close');close.onclick=event=>{event.stopPropagation();closeTab(tab.id);};node.append(close);node.onclick=()=>selectTab(tab.id);node.onkeydown=event=>{if(['Enter',' '].includes(event.key)){event.preventDefault();selectTab(tab.id);}if(['ArrowLeft','ArrowRight'].includes(event.key)){event.preventDefault();const next=(index+(event.key==='ArrowRight'?1:-1)+state.tabs.length)%state.tabs.length;selectTab(state.tabs[next].id);$('tabs').children[next].focus();}};tabs.append(node);
  });
}
function renderBookmarks(){
  const bar=$('bookmark-bar');bar.replaceChildren();
  if(!state.bookmarks.length){bar.append(textNode('span','bookmark-empty','Use the star to save a website here.'));return;}
  state.bookmarks.forEach(entry=>{const button=document.createElement('button');button.className='bookmark-chip';button.innerHTML=icon('globe');button.append(textNode('span','',entry.title));button.title=entry.url;button.onclick=()=>navigate(entry.url);button.oncontextmenu=event=>{event.preventDefault();if(confirm(`Remove “${entry.title}” from bookmarks?`)){state.bookmarks=state.bookmarks.filter(item=>item.url!==entry.url);persist();renderBookmarks();renderToolbar();}};bar.append(button);});
}
function renderRecent(){const list=$('recent-list');list.replaceChildren();if(!state.history.length)list.append(textNode('div','empty-history','Your recent websites will appear here.'));else state.history.slice(0,4).forEach(entry=>list.append(historyRow(entry)));}
function renderGames(){
  $('games-count').textContent=String(verifiedGames.length);
  $('games-empty').hidden=verifiedGames.length>0;
  $('games-list').replaceChildren();
  for(const game of verifiedGames){
    const button=textNode('button','game-entry','');button.type='button';
    button.append(textNode('span','game-title',game.title),textNode('span','game-domain',new URL(game.url).hostname));
    if(game.note)button.append(textNode('span','game-note',game.note));
    button.title=game.checked;
    button.onclick=()=>navigate(game.url);$('games-list').append(button);
  }
}
function renderHistory(){
  const list=$('history-list'),term=$('history-search').value.toLowerCase().trim();list.replaceChildren();const entries=state.history.filter(entry=>(entry.title+' '+entry.url).toLowerCase().includes(term));
  if(!entries.length){list.append(textNode('div','empty-history',term?'No websites match your search.':'No browsing history yet.'));return;}
  entries.forEach(entry=>{const item=textNode('div','history-item','');item.append(historyRow(entry));const remove=document.createElement('button');remove.className='icon-button';remove.innerHTML=icon('close');remove.setAttribute('aria-label',`Remove ${entry.title} from history`);remove.onclick=()=>{state.history=state.history.filter(value=>value.url!==entry.url);persist();renderHistory();renderRecent();};item.append(remove);list.append(item);});
}
function renderToolbar(){
  const tab=active();$('address').value=tab.url;$('back').disabled=tab.position<1;$('forward').disabled=tab.position>=tab.trail.length-1;$('reload').disabled=!tab.url;$('bookmark-page').disabled=!tab.url;const bookmarked=state.bookmarks.some(entry=>entry.url===tab.url);$('bookmark-page').classList.toggle('saved',bookmarked);$('bookmark-page').setAttribute('aria-label',bookmarked?'Remove bookmark':'Bookmark this page');$('bookmark-page').setAttribute('aria-pressed',String(bookmarked));const running=runtime.get(tab.id);$('loading').hidden=!running?.loading;$('page-status').textContent=running?.loading?'Loading website':tab.url?new URL(tab.url).hostname:'New tab';document.title=tab.url?`${tab.title} — Orbit`:'Orbit — Personal browser';renderGameDetails();renderBlocking();
}
function renderGameDetails(){
  const report=runtime.get(state.activeId)?.gameDetails;
  const stalled=report&&['stalled','error','starting'].includes(report.stage);
  $('game-loading-status').hidden=!stalled;
  $('game-loading-status').textContent=report?.stage==='error'?'Game reported an error':'Game loading stalled';
  $('game-details-message').textContent=stalled?'PokéRogue’s loading report is available for troubleshooting.':'No loading failure has been recorded for this tab.';
  const lines=[];
  if(report){
    lines.push(`Stage: ${report.stage}`);
    if(report.scene)lines.push(`Scene: ${report.scene}`);
    for(const [name,label]of [['downloaded','Downloaded'],['failed','Failed downloads'],['downloading','Downloading'],['waiting','Waiting'],['processing','Processing']])if(report[name]!==undefined)lines.push(`${label}: ${report[name]}`);
    for(const file of report.pending||[])lines.push(`Pending ${file.type}: ${file.key} (state ${file.state})`);
    if(report.error){lines.push(`${report.error.name}: ${report.error.message}`,...report.error.frames);}
  }
  $('game-details-text').textContent=lines.join('\n');
}
function openGameDetails(){renderGameDetails();$('settings-dialog').close();$('game-details-dialog').showModal();}
function showActive(){
  const tab=active();$('new-page').hidden=!!tab.url;$('page-error').hidden=true;
  for(const [id,view]of runtime)view.frame.frame.classList.toggle('active',id===state.activeId && !!tab.url);
  renderTabs();renderToolbar();renderRecent();renderSiteNotice();
}
async function selectTab(id){state.activeId=id;persist();showActive();const tab=active();if(tab.url && !runtime.has(id))await navigate(tab.url,{record:false});}
function newTab(){if(state.tabs.length>=20){notify('Close a tab before opening another.');return;}const tab=freshState().tabs[0];state.tabs.push(tab);state.activeId=tab.id;persist();showActive();$('home-address').focus();}
function closeTab(id){const index=state.tabs.findIndex(tab=>tab.id===id);const view=runtime.get(id);if(view){clearTimeout(view.timer);view.frame.frame.remove();runtime.delete(id);}state.tabs.splice(index,1);if(!state.tabs.length)state.tabs.push(freshState().tabs[0]);if(state.activeId===id)state.activeId=state.tabs[Math.min(index,state.tabs.length-1)].id;persist();selectTab(state.activeId);}
function showError(tab,error){const view=runtime.get(tab.id);if(view){view.loading=false;clearTimeout(view.timer);}if(state.activeId!==tab.id)return;renderToolbar();$('error-title').textContent='This page couldn’t load';$('error-message').textContent=error.message||String(error);$('page-error').hidden=false;}
function beginLoad(tab,view){
  view.gameDetails=null;view.diagnosticSignatures=new Set();view.siteIssue=null;view.noticeDismissed=false;
  if(tab.id===state.activeId)renderSiteNotice();
  view.loading=true;clearTimeout(view.timer);view.timer=setTimeout(()=>showError(tab,new Error('This website is taking too long to respond. Try again or check your browsing connection.')),60000);if(tab.id===state.activeId){$('page-error').hidden=true;renderToolbar();}
}
async function createFrameForTab(tab){
  const engine=await ensureEngine();if(!state.tabs.includes(tab))throw new Error('This tab was closed.');
  const frame=engine.createFrame();frame.frame.id=`frame-${tab.id}`;frame.frame.title=tab.title;frame.frame.setAttribute('allow','cross-origin-isolated; fullscreen; clipboard-read; clipboard-write; autoplay; gamepad');frame.frame.setAttribute('allowfullscreen','');frame.frame.setAttribute('referrerpolicy','no-referrer');
  const view={frame,loading:false,timer:null};runtime.set(tab.id,view);$('frames').append(frame.frame);
  frame.addEventListener('error',event=>showError(tab,new Error(event.message)));
  frame.addEventListener('navigate',()=>beginLoad(tab,view));
  frame.addEventListener('open-tab',event=>{
    if(!state.tabs.includes(tab))return;
    if(!validUrl(event.url)){notify('This website requested an empty popup. It needs a website address to open in Orbit.');return;}
    if(state.tabs.length>=20){notify('Close a tab before opening another.');return;}
    newTab();navigate(event.url);
  });
  frame.addEventListener('urlchange',event=>{
    const url=String(event.url);if(!validUrl(url))return;
    // Preserve the app's forward history when an iframe reports the selected URL.
    if(url!==tab.url && tab.trail[tab.position-1]===url)tab.position--;else if(url!==tab.url && tab.trail[tab.position+1]===url)tab.position++;
    if(tab.trail[tab.position]===url)tab.url=url;
    let title=frame.title;try{title ||= frame.frame.contentDocument?.title;}catch{}
    recordVisit(state,tab,url,title||frame.title||new URL(url).hostname,{recordHistory:preferences.saveHistory});persist();if(tab.id===state.activeId){renderTabs();renderToolbar();renderSiteNotice();}renderRecent();
  });
  frame.frame.addEventListener('load',()=>{
    if('hasLoaded'in frame&&!frame.hasLoaded)return;
    if(!tab.url || frame.frame.contentDocument?.URL==='about:blank')return;view.loading=false;clearTimeout(view.timer);
    try{
      const doc=frame.frame.contentDocument,title=frame.title||doc?.title?.trim();
      doc?.addEventListener('keydown',browserKeys,{capture:true});
      if((title && /scramjet.*error|error.*scramjet/i.test(title)) || (title==='Scramjet' && doc?.getElementById('errorTrace'))){showError(tab,new Error('The website couldn’t be reached through the browsing connection. Try again or open Settings to check the relay.'));return;}
      if(title && title!=='about:blank'){tab.title=title;frame.frame.title=title;const entry=state.history.find(item=>item.url===tab.url);if(entry)entry.title=title;persist();}
    }catch{}
    if(tab.id===state.activeId){renderTabs();renderToolbar();if(document.activeElement===document.body)frame.frame.focus();}renderRecent();
  });
  return view;
}
function makeFrame(tab){
  if(pendingFrames.has(tab.id))return pendingFrames.get(tab.id);
  const promise=createFrameForTab(tab).finally(()=>pendingFrames.delete(tab.id));
  pendingFrames.set(tab.id,promise);return promise;
}
async function navigate(input,{record=true}={}){
  const tab=active();let url;
  const version=(navigationVersions.get(tab.id)||0)+1;navigationVersions.set(tab.id,version);
  try{url=resolveAddress(input,state.engine);}catch(error){notify(error.message);return;}
  const destination=new URL(url),fragment=new URLSearchParams(destination.hash.slice(1));
  // Account links open on Orbit’s trusted account origin, never inside a
  // proxied website or in saved browsing history.
  if(destination.origin===location.origin&&(fragment.has('invite')||fragment.has('setup'))){location.assign(url);return;}
  if(record)recordVisit(state,tab,url,new URL(url).hostname,{recordHistory:preferences.saveHistory});else{tab.url=url;tab.title=tab.title||new URL(url).hostname;}
  persist();showActive();$('page-status').textContent='Preparing website';
  try{
    const previous=runtime.get(tab.id);if(previous?.frame.failed){clearTimeout(previous.timer);previous.frame.destroy();runtime.delete(tab.id);}
    const view=runtime.get(tab.id)||await makeFrame(tab);if(!state.tabs.includes(tab) || navigationVersions.get(tab.id)!==version)return;
    beginLoad(tab,view);view.frame.go(url);if(tab.id===state.activeId)showActive();
    }catch(error){if(navigationVersions.get(tab.id)===version)showError(tab,error);}
}
function navigateHistory(direction){const tab=active(),next=tab.position+direction;if(next<0 || next>=tab.trail.length)return;tab.position=next;tab.url=tab.trail[next];persist();navigate(tab.url,{record:false});}
function goHome(){const tab=active(),view=runtime.get(tab.id);if(view){view.frame.frame.classList.remove('active');view.loading=false;clearTimeout(view.timer);}tab.url='';tab.title='New tab';persist();showActive();$('home-address').focus();}
function openHistory(){renderHistory();$('history-dialog').showModal();$('history-search').focus();}
function openSettings(){applyPreferences();$('search-engine').value=state.engine;$('custom-relay').value=state.relay;$('connection-detail').textContent=connectionMessage;$('settings-dialog').showModal();}

$('new-tab').onclick=newTab;$('address-form').onsubmit=event=>{event.preventDefault();navigate($('address').value);$('address').blur();};$('home-search').onsubmit=event=>{event.preventDefault();navigate($('home-address').value);$('home-address').blur();};
$('back').onclick=()=>navigateHistory(-1);$('forward').onclick=()=>navigateHistory(1);$('reload').onclick=()=>{const tab=active(),view=runtime.get(tab.id);if(view){beginLoad(tab,view);view.frame.reload();}else if(tab.url)navigate(tab.url,{record:false});};$('home').onclick=goHome;$('error-home').onclick=goHome;$('retry').onclick=()=>navigate(active().url,{record:false});
$('bookmark-page').onclick=()=>{const tab=active();if(!tab.url)return;const saved=state.bookmarks.some(entry=>entry.url===tab.url);if(saved)state.bookmarks=state.bookmarks.filter(entry=>entry.url!==tab.url);else state.bookmarks.push({url:tab.url,title:tab.title,time:Date.now()});persist();renderBookmarks();renderToolbar();notify(saved?'Bookmark removed.':'Bookmark saved.');};
$('history-button').onclick=openHistory;$('view-history').onclick=openHistory;$('history-search').oninput=renderHistory;$('settings-button').onclick=openSettings;$('connection-status').onclick=openSettings;$('recheck').onclick=checkConnection;
$('game-loading-status').onclick=openGameDetails;$('open-game-details').onclick=openGameDetails;
$('fullscreen-button').onclick=()=>setFullscreen(!controlsHidden);$('restore-controls').onclick=()=>setFullscreen(false);
$('dismiss-site-notice').onclick=()=>{const view=runtime.get(state.activeId);if(view)view.noticeDismissed=true;renderSiteNotice();};
$('adblock-button').onclick=()=>{openSettings();$('blocking-settings').scrollIntoView({block:'start'});$('adblock-enabled').focus({preventScroll:true});};
$('settings-history').onclick=()=>{$('settings-dialog').close();openHistory();};
$('theme').onchange=event=>{preferences.theme=event.target.value;savePreferences();};
for(const [id,key]of [['compact-toolbar','compact'],['show-bookmarks','showBookmarks'],['show-status','showStatus'],['reduced-motion','reducedMotion'],['save-history','saveHistory'],['restore-tabs','restoreTabs']])$(id).onchange=event=>{preferences[key]=event.target.checked;savePreferences();};
$('adblock-enabled').onchange=event=>{preferences.adblock=event.target.checked;savePreferences();syncBlocking().catch(()=>notify('Reload Orbit to update ad blocking.'));notify('Ad blocking updated. Reload the website to apply it to loaded content.');};
$('site-ads').onchange=event=>{const host=currentHost();if(!host)return;preferences.allowedSites=preferences.allowedSites.filter(site=>site!==host);if(event.target.checked)preferences.allowedSites.push(host);savePreferences();syncBlocking().catch(()=>notify('Reload Orbit to update ad blocking.'));notify('Ad blocking updated for this website. Reload it when you’re ready.');};
$('clear-history').onclick=()=>{if(!state.history.length || !confirm('Clear your browsing history?'))return;state.history=[];persist();renderHistory();renderRecent();notify('History cleared.');};
$('search-engine').onchange=event=>{state.engine=event.target.value;persist();};
$('save-relay').onclick=async()=>{
  const value=$('custom-relay').value.trim();if(value && !validRelay(value)){notify('Enter a secure wss:// relay address.');return;}
  state.relay=value;persist();try{await syncBlocking();await checkConnection();notify(connectionState==='connected'?'Connection saved.':'Saved. The relay couldn’t be reached.');}catch{notify('The relay couldn’t be configured.');}
};
$('clear-all').onclick=async()=>{
  if(!confirm('Clear this account’s tabs, bookmarks, history, settings and website data on this device?'))return;
  try{const engine=await ensureEngine();let frame=controller?.frames.values().next().value,temporary=false;if(!frame){frame=engine.createFrame();temporary=true;frame.frame.hidden=true;document.body.append(frame.frame);await frame.ready;await frame.migration;}await frame.command('clear-profile');if(temporary)frame.destroy();
  for(const view of runtime.values()){clearTimeout(view.timer);view.frame.destroy();}runtime.clear();localStorage.clear();location.reload();}catch(error){notify(error.message);}
};
for(const [label,url,letter]of [['PokéRogue','https://pokerogue.net/','P'],['Password Game','https://neal.fun/password-game/','N'],['Google','https://www.google.com/','G'],['YouTube','https://www.youtube.com/','Y']]){const button=document.createElement('button');button.className='shortcut';button.append(textNode('span','shortcut-emblem',letter),textNode('span','',label));button.onclick=()=>navigate(url);$('shortcuts').append(button);}
document.addEventListener('keydown',browserKeys);
document.querySelectorAll('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left || event.clientX>r.right || event.clientY<r.top || event.clientY>r.bottom)dialog.close();}}));

function installAgentTools(){
  const context=document.modelContext;if(!context?.registerTool)return;
  const lifecycle=new AbortController();const tools=[
    {name:'list_browser_tabs',title:'List browser tabs',description:'Read the current Orbit tabs and selected tab.',inputSchema:{type:'object',properties:{},additionalProperties:false},annotations:{readOnlyHint:true,untrustedContentHint:true},execute:()=>({tabs:state.tabs.map(({id,title,url})=>({id,title,url})),activeId:state.activeId})},
    {name:'navigate_browser_tab',title:'Navigate browser tab',description:'Open a website or search in the selected Orbit tab.',inputSchema:{type:'object',properties:{address:{type:'string',minLength:1}},required:['address'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:true},execute:async input=>{if(!input || typeof input.address!=='string' || !input.address.trim())throw new Error('A website address or search is required.');const url=resolveAddress(input.address,state.engine);await navigate(url);return {tabId:state.activeId,url:active().url};}},
  ];for(const tool of tools)try{Promise.resolve(context.registerTool(tool,{signal:lifecycle.signal})).catch(()=>{});}catch{}
  window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
}
applyPreferences();renderBookmarks();renderGames();showActive();persist();installAgentTools();
(async()=>{try{const response=await fetch('/api/config',{cache:'no-store'});if(response.ok){const config=await response.json();sharedRelay=config.shared!==false;}}catch{}await checkConnection();})();
if(active().url)navigate(active().url,{record:false});
