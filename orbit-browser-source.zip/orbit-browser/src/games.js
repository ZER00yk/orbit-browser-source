// Agent play checks and the owner's Chromebook results, 9 October 2026 (Pacific).
// Catalog entries confirm access to games, not every game in the catalog.
export const verifiedGames=[
  {title:'Password Game',url:'https://neal.fun/password-game/',checked:'Typing updated the password rules and advanced to rule 5.'},
  {title:'Infinite Craft',url:'https://neal.fun/infinite-craft/',checked:'Crafted Steam and Engine; both discoveries survived a reload.'},
  {title:'Little Alchemy 2',url:'https://littlealchemy2.com/',checked:'Crafted Steam; the discovery survived a reload.'},
  {title:'Diablo (free demo)',url:'https://johnimril.github.io/diablo_web/',checked:'Played the shareware demo, tested movement and inventory, saved, then reloaded and resumed the saved game.'},
  {title:'PokéRogue',url:'https://pokerogue.net/',checked:'Owner confirmed working in Orbit on Chromebook.'},
  {title:'The Simpsons: Hit & Run',url:'https://shar-wasm.cjoseph.workers.dev/?skipmovie',checked:'Owner confirmed working in Orbit on Chromebook.'},
  {title:'Quake 1',url:'https://q1.pieter.com',checked:'Owner confirmed working in Orbit on Chromebook.'},
  {title:'Quake 2',url:'https://q2.pieter.com',note:'Works · slow loading',checked:'Owner confirmed working, with very slow loading on Chromebook.'},
  {title:'Quake 3',url:'https://q3.pieter.com',note:'Works · slow loading',checked:'Owner confirmed working, with very slow loading on Chromebook.'},
  {title:'Return to Castle Wolfenstein',url:'https://rtcw.pieter.com',note:'Works · very slow loading',checked:'Owner confirmed working, with very slow loading on Chromebook.'},
  {title:'Urban Terror',url:'https://ut.pieter.com',note:'Works · very slow loading',checked:'Owner confirmed working, with very slow loading on Chromebook. This is Urban Terror.'},
  {title:'Half-Life',url:'https://pixelsuft.github.io/hl/',note:'Works · extremely slow loading',checked:'Owner confirmed working, with extremely slow loading on Chromebook.'},
  {title:'CrazyGames',url:'https://www.crazygames.com/',note:'Game catalog',checked:'Owner confirmed the catalog works in Orbit.'},
  {title:'Poki',url:'https://poki.com/',note:'Game catalog',checked:'Owner confirmed games from this catalog work in Orbit.'},
  {title:'itch.io browser games',url:'https://itch.io/games/html5',note:'Game catalog',checked:'Owner confirmed this catalog works in Orbit.'},
];
