import './style.css';
import {initialiseAccount} from './account.js';
// The account origin never hosts game pages or registers a proxy worker.
(async()=>{
// The dynamic entrypoint supplies the headers that the static host omits.
// Preserve invitation fragments and the existing session during this redirect.
if(location.pathname!=='/api/app'){location.replace('/api/app'+location.search+location.hash);return;}
if(navigator.serviceWorker){for(const registration of await navigator.serviceWorker.getRegistrations()){if(registration.scope.startsWith(location.origin+'/'))await registration.unregister();}}
await initialiseAccount();})();
