import {currentAccount} from './account.js';
const nativeStorage=window.localStorage;
let migration;
const result=request=>new Promise((resolve,reject)=>{request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);});
async function legacyData(){
  const local=[];for(const name of Object.keys(nativeStorage))if(/^[^@]+@.+/.test(name)&&!name.startsWith('orbit:'))local.push([name,nativeStorage.getItem(name)]);
  let cookies={},databases=[];
  if(indexedDB.databases)for(const info of await indexedDB.databases()){
    if(info.name!=='$scramjet'&&!/^https?:\/\//.test(info.name||''))continue;
    const db=await result(indexedDB.open(info.name));try{
      if(info.name==='$scramjet'){if(db.objectStoreNames.contains('cookies'))cookies=await result(db.transaction('cookies').objectStore('cookies').get('cookies'))||{};continue;}
      const stores=[];
      for(const name of db.objectStoreNames){const store=db.transaction(name).objectStore(name);const [records,keys]=await Promise.all([result(store.getAll()),result(store.getAllKeys())]);stores.push({name,keyPath:store.keyPath,autoIncrement:store.autoIncrement,indexes:Array.from(store.indexNames,name=>{const index=store.index(name);return {name,keyPath:index.keyPath,unique:index.unique,multiEntry:index.multiEntry};}),records,keys});}
      databases.push({name:info.name,version:db.version,stores});
    }finally{db.close();}
  }
  return {local,cookies,databases};
}
export function migrateOwner(frame){
  const user=currentAccount();if(user?.role!=='owner'||nativeStorage.getItem('orbit.migrated.'+user.id))return Promise.resolve();
  if(!migration)migration=(async()=>{
    const data=await legacyData();if(!data.local.length&&!data.databases.length&&!Object.keys(data.cookies).length){nativeStorage.setItem('orbit.migrated.'+user.id,'1');return;}
    await frame.command('import-legacy',{data});
    // Leave source game data intact until the encrypted destination is confirmed.
    nativeStorage.setItem('orbit.migrated.'+user.id,'1');
  })().catch(error=>{migration=null;throw error;});return migration;
}
