importScripts('/profile-runtime.js?v=4','/scram/scramjet.all.js?v=2.0.0-orbit.8');
importScripts('/adblock-hosts.js?v=2026-09-27','/adblock.js?v=1');
importScripts('/site-status.js?v=3');
importScripts('/app-links.js?v=5');
const { ScramjetServiceWorker }=$scramjetLoadWorker();
let scramjet,profileId,profileUntil=0,pendingProfile;
async function ensureProfile(force=false){
  if(!force&&scramjet&&Date.now()<profileUntil)return scramjet;
  if(pendingProfile)return pendingProfile;
  return pendingProfile=(async()=>{const response=await fetch('/api/context',{cache:'no-store',credentials:'include'});if(!response.ok)throw new Error('Sign in to Orbit again.');const context=await response.json();
    OrbitProfile.configure(context);if(!scramjet||context.id!==profileId){profileId=context.id;scramjet=new ScramjetServiceWorker();attachListeners(scramjet);}profileUntil=Date.now()+30000;return scramjet;
  })().finally(()=>{pendingProfile=null;});
}
function attachListeners(scramjet){
scramjet.addEventListener('request',event=>{
  // Explicit top-level navigation is allowed. Listed advertising subresources
  // receive an empty response before the transport connects to their server.
  if(event.destination==='document')return;
  const policy=scramjet.config?.orbitAdblock||{enabled:true,allowedSites:[]};
  const site=self.OrbitAdBlock.pageHost(event.client?.url,self.location.origin,scramjet.config?.prefix||'/browse/');
  if(!self.OrbitAdBlock.shouldBlock(event.url.hostname,site,policy,self.ORBIT_AD_HOSTS))return;
  event.response=self.OrbitAdBlock.response();
  self.clients?.matchAll({type:'window'}).then(clients=>{
    for(const client of clients)if(!new URL(client.url).pathname.startsWith('/browse/'))client.postMessage({type:'orbit-adblock-blocked',site});
  }).catch(()=>{});
});
scramjet.addEventListener('handleResponse',event=>{
  if(['document','iframe','worker','sharedworker'].includes(event.destination)){
    // Every document/worker below the isolated runtime must opt in too.
    // This must also work when an older service-worker realm isn't isolated.
    event.responseHeaders['Cross-Origin-Embedder-Policy']='require-corp';
    event.responseHeaders['Cross-Origin-Opener-Policy']='same-origin';
  }
  const notice=self.OrbitSiteStatus.notice(event);
  if(notice){
    self.clients?.matchAll({type:'window'}).then(clients=>{
      for(const client of clients)if(!new URL(client.url).pathname.startsWith('/browse/'))client.postMessage(notice);
    }).catch(()=>{});
  }
  const document=['document','iframe'].includes(event.destination)&&typeof event.responseBody==='string'&&event.responseHeaders['content-type']?.startsWith('text/html');
  if(document&&(!event.status||event.status>=200&&event.status<300)&&!notice){
    let scripts='<script src="/orbit-navigation.js?v=1"></script>';
    // vel.gg's supported fallback starts the engine only after boot-ready.
    // Mounting OPFS while the encrypted downloader is still creating the boot
    // tree can leave WasmFS with a partial pack. Never clear verified downloads.
    if(event.url?.hostname==='vel.gg'&&/^\/bo1z(?:\/|$)/.test(event.url.pathname))scripts+='<script>globalThis.__kisakNoOverlap=true;</script>';
    event.responseBody=event.responseBody.replace(/<head\b[^>]*>/i,match=>match+scripts);
  }
  if(!['document','iframe'].includes(event.destination)||event.url?.hostname!=='pokerogue.net'||typeof event.responseBody!=='string'||!event.responseHeaders['content-type']?.startsWith('text/html'))return;
  // Run before Scramjet's page hooks and the game's modules, so early errors
  // can be observed too. This file is an Orbit asset, not rewritten game code.
  event.responseBody=event.responseBody.replace(/<head\b[^>]*>/i,match=>match+'<script src="/game-diagnostics.js?v=2"></script>');
});
}
self.addEventListener('message',event=>{if(event.data?.type!=='orbit-profile-ready')return;event.waitUntil((async()=>{try{const client=await self.clients.get(event.source.id);if(!client||!['/','/api/runtime/'].includes(new URL(client.url).pathname))throw new Error('Open this profile from Orbit.');await ensureProfile(true);if(event.data.reloadCookies){const db=await scramjet.openIDB?.();if(db){scramjet.cookieStore.load(OrbitProfile.cookieDump(await db.get("cookies","cookies")));db.close();}else{scramjet.orbitEngineReady=null;await scramjet.loadConfig();}}event.ports[0]?.postMessage({ok:true});}catch(error){event.ports[0]?.postMessage({ok:false,error:error.message});}})());});
self.addEventListener('install',event=>event.waitUntil(self.skipWaiting()));
self.addEventListener('activate',event=>event.waitUntil(self.clients.claim()));
self.addEventListener('fetch',event=>{
  // Let Orbit's own assets load even before its proxy configuration exists.
  const url=new URL(event.request.url);
  if(url.origin!==self.location.origin || !(url.pathname.startsWith('/browse/') || url.pathname==='/scram/scramjet.wasm.wasm'))return;
  event.respondWith((async()=>{
    const scramjet=await ensureProfile();
    // Native app launch links must never reach libcurl's HTTP transport. Keep
    // any launch ticket inside the engine page, and require an explicit click.
    const app=self.OrbitAppLinks.response(self.OrbitAppLinks.destination(url,scramjet.config?.prefix||'/browse/'),['document','iframe'].includes(event.request.destination));
    if(app)return app;
    await scramjet.loadConfig();
    if(scramjet.route(event))return scramjet.fetch(event);
    return fetch(event.request);
  })());
});
