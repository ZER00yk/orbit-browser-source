import LibcurlClient,{libcurl} from './libcurl/index.mjs?v=2.0.5-orbit.1';
import {createDnsTransport} from './wisp-dns.mjs?v=1';

// Keep bare-mux 2's header contract while using the corrected libcurl startup.
const rawHeaders=headers=>Array.isArray(headers)?headers:Object.entries(headers||{});
const connectionFailure=error=>[5,6,7,35].includes(Number(String(error?.message||'').match(/Request failed with error code (\d+):/)?.[1]));
function waitToRetry(milliseconds,signal){
  return new Promise((resolve,reject)=>{
    const abort=()=>{clearTimeout(timer);signal?.removeEventListener('abort',abort);reject(signal.reason||new DOMException('The operation was aborted.','AbortError'));};
    const timer=setTimeout(()=>{signal?.removeEventListener('abort',abort);resolve();},milliseconds);
    signal?.addEventListener('abort',abort,{once:true});if(signal?.aborted)abort();
  });
}
export default class OrbitTransport extends LibcurlClient {
  constructor(options){
    const dns=createDnsTransport(libcurl.wisp.WispWebSocket);
    super({...options,transport:!options.transport||options.transport==='wisp'?dns.Socket:options.transport});
    this.recoverDNS=this.transport===dns.Socket?dns.recover:async()=>false;
  }
  initialization=null;
  init(){
    // A game's parallel script requests must share the same WASM readiness wait.
    if(!this.initialization)this.initialization=super.init().catch(error=>{this.initialization=null;throw error;});
    return this.initialization;
  }
  async request(remote,method,body,headers,signal){
    signal?.throwIfAborted();
    // Buffer streamed uploads once so a failed connection can retry the exact
    // bytes. Only DNS/connect/TLS-handshake errors qualify: no HTTP request has
    // reached the server. Never replay a save or guess after an HTTP response,
    // timeout, send error, or receive error with an unknown commit outcome.
    if(body instanceof ReadableStream)body=await new Response(body).arrayBuffer();
    let response;
    for(let attempt=0;attempt<3;attempt++){
      signal?.throwIfAborted();
      try{response=await super.request(remote,method,body,rawHeaders(headers),signal);break;}
      catch(error){
        if(attempt===2||signal?.aborted||!connectionFailure(error))throw error;
        if(!await this.recoverDNS(remote.hostname,signal))await waitToRetry([250,750][attempt],signal);
      }
    }
    const converted=Object.create(null);
    for(const [name,value] of response.headers){
      const key=name.toLowerCase();
      (converted[key] ||= []).push(value);
    }
    return {...response,headers:converted};
  }
  connect(url,protocols,headers,...callbacks){
    return super.connect(url,protocols,rawHeaders(headers),...callbacks);
  }
}
