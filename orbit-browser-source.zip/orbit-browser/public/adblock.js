/* Domain blocking only: no page scripts, storage, or game assets are modified. */
(()=>{
  function matches(host,domains){
    host=String(host||'').toLowerCase().replace(/\.$/,'');
    while(host.includes('.')){if(domains.has(host))return true;host=host.slice(host.indexOf('.')+1);}
    return false;
  }
  function pageHost(address,origin,prefix){
    try{const url=new URL(address);if(url.origin!==origin||!url.pathname.startsWith(prefix))return '';return new URL(decodeURIComponent(url.pathname.slice(prefix.length))).hostname;}catch{return '';}
  }
  function shouldBlock(host,site,policy,domains){
    if(policy?.enabled===false)return false;
    if(matches(site,new Set(policy?.allowedSites||[])))return false;
    return matches(host,domains);
  }
  function response(){
    const result=new Response(null,{status:204,headers:{'Access-Control-Allow-Origin':'*','Cross-Origin-Resource-Policy':'cross-origin','Cache-Control':'no-store'}});
    // Scramjet's request hook consumes BareResponseFetch-compatible headers.
    result.rawHeaders=Object.fromEntries(result.headers.entries());
    return result;
  }
  self.OrbitAdBlock={matches,pageHost,shouldBlock,response};
})();
