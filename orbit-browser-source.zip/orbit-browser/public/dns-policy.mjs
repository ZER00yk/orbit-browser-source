export function publicIPv4(address){
  if(typeof address!=='string'||!/^\d{1,3}(?:\.\d{1,3}){3}$/.test(address))return false;
  const octets=address.split('.').map(Number),[a,b,c]=octets;
  if(octets.some((n,i)=>n>255||String(n)!==address.split('.')[i]))return false;
  return !(a===0||a===10||a===127||a>=224||a===100&&b>=64&&b<=127||a===169&&b===254||
    a===172&&b>=16&&b<=31||a===192&&(b===168||b===0||b===88&&c===99)||
    a===198&&(b===18||b===19||b===51&&c===100)||a===203&&b===0&&c===113);
}
export function publicHostname(hostname){
  if(typeof hostname!=='string'||hostname.length>253||/^\d+(?:\.\d+){3}$/.test(hostname))return false;
  const labels=hostname.split('.');
  return labels.length>1&&labels.every(label=>/^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/.test(label))&&
    !['localhost','local','internal','onion','invalid','test'].includes(labels.at(-1));
}
