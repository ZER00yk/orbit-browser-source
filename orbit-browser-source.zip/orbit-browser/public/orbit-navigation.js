(()=>{
  // The service worker inserts this after rewriting, before website scripts.
  // Keep links/forms that ask for a browser window inside their Orbit frame.
  const contained=new Set(['_blank','_top','_parent','_unfencedTop']);
  const stay=element=>{if(element&&contained.has(String(element.target).toLowerCase()))element.target='_self';};
  document.addEventListener('click',event=>{
    if(event.defaultPrevented)return;
    const link=event.composedPath().find(element=>element?.tagName==='A'||element?.tagName==='AREA');
    stay(link);
  },true);
  document.addEventListener('submit',event=>{stay(event.target);const button=event.submitter;if(button&&contained.has(String(button.formTarget).toLowerCase()))button.formTarget='_self';},true);
})();
