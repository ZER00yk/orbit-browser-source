import {sqliteTable,text,integer,uniqueIndex} from 'drizzle-orm/sqlite-core';
import {sql} from 'drizzle-orm';
export const users=sqliteTable('users',{
  id:text('id').primaryKey(),username:text('username').notNull().unique(),password:text('password').notNull(),
  role:text('role').notNull(),created:integer('created').notNull(),disabled:integer('disabled').notNull().default(0),
},t=>[uniqueIndex('one_owner').on(t.role).where(sql`${t.role} = 'owner'`)]);
export const sessions=sqliteTable('sessions',{
  hash:text('hash').primaryKey(),userId:text('user_id').notNull().references(()=>users.id,{onDelete:'cascade'}),expires:integer('expires').notNull(),
  remembered:integer('remembered').notNull().default(1),
});
export const invites=sqliteTable('invites',{
  hash:text('hash').primaryKey(),ownerId:text('owner_id').notNull().references(()=>users.id),expires:integer('expires').notNull(),
  claimedBy:text('claimed_by').references(()=>users.id),
});
export const profiles=sqliteTable('profiles',{
  userId:text('user_id').primaryKey().references(()=>users.id,{onDelete:'cascade'}),cipher:text('cipher').notNull(),updated:integer('updated').notNull(),
});
export const limits=sqliteTable('auth_limits',{
  key:text('key').primaryKey(),count:integer('count').notNull(),expires:integer('expires').notNull(),
});
