import test from 'node:test';
import assert from 'node:assert/strict';
import {rewriteDynamicImports} from '../src/module-imports.js';

test('rewrites dynamic imports inside functions while preserving other import syntax',()=>{
  const source=`const text="import('ignored.js')";
// import('ignored-comment.js')
import "./static.js";
export async function start(base){
  const module=await import(base+"artifacts/KisakBlack-web.mjs");
  const other=import /* a comment */ ("./other.js",{with:{type:"json"}});
  return [module,other,import.meta.url];
}`;
  const rewritten=rewriteDynamicImports(source,'https://vel.gg/bo1z/','$scramjet$import');
  assert.match(rewritten,/await \$scramjet\$import\("https:\/\/vel\.gg\/bo1z\/",base\+"artifacts\/KisakBlack-web\.mjs"\)/);
  assert.match(rewritten,/const other=\$scramjet\$import\("https:\/\/vel\.gg\/bo1z\/","\.\/other\.js",\{with:\{type:"json"\}\}\)/);
  assert.match(rewritten,/import "\.\/static\.js"/);
  assert.match(rewritten,/import\.meta\.url/);
  assert.equal((rewritten.match(/\$scramjet\$import\(/g)||[]).length,2);
});

test('accepts byte sources and leaves unterminated calls unchanged',()=>{
  const bytes=new TextEncoder().encode('export const load=()=>import("./asset.mjs");');
  const rewritten=rewriteDynamicImports(bytes,'https://example.test/app/','$scramjet$import');
  assert.equal(typeof rewritten,'string');
  assert.match(rewritten,/\$scramjet\$import\("https:\/\/example\.test\/app\/","\.\/asset\.mjs"\)/);
  const broken='export const load=()=>import("./asset.mjs";';
  assert.equal(rewriteDynamicImports(broken,'https://example.test/app/','$scramjet$import'),broken);
});
