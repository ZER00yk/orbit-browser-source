import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import worker from '../server/worker.mjs';
const app='https://orbit.example',engine='https://profiles.example';
async function helpers(){const self={},context=vm.createContext({self,URL,Response});for(const name of ['app-links','site-status'])vm.runInContext(await readFile(new URL('../public/'+name+'.js',import.meta.url),'utf8'),context);return self;}

test('the account and engine entrypoints attach isolation headers on asset misses, without changing either origin',async()=>{
  const assets=[],ASSETS={fetch:async request=>{assets.push(request);return new Response('<html>entry</html>',{headers:{'Content-Type':'text/html'}});}};
  const page=await worker.fetch(new Request(app+'/api/app'),{ORBIT_ENGINE_ORIGIN:engine,ASSETS});
  assert.equal(await page.text(),'<html>entry</html>');assert.equal(assets.at(-1).url,app+'/index.html');
  assert.equal(page.headers.get('Cross-Origin-Opener-Policy'),'same-origin');assert.equal(page.headers.get('Cross-Origin-Embedder-Policy'),'require-corp');
  assert.equal(page.headers.get('Permissions-Policy'),'cross-origin-isolated=(self "'+engine+'")');assert.match(page.headers.get('Content-Security-Policy'),/frame-ancestors 'none'/);assert.equal(page.headers.get('Cache-Control'),'no-store');
  for(const [path,file]of [['/api/runtime/','/index.html'],['/api/runtime/sw.js','/sw.js'],['/api/runtime/connection.js','/baremux/worker.js']]){
    const response=await worker.fetch(new Request(engine+path),{ORBIT_MODE:'engine',ORBIT_APP_ORIGIN:app,ASSETS});
    assert.equal(response.status,200);assert.equal(assets.at(-1).url,engine+file);assert.equal(response.headers.get('Cross-Origin-Embedder-Policy'),'require-corp');assert.equal(response.headers.get('Cross-Origin-Resource-Policy'),'cross-origin');
    if(file==='/sw.js')assert.equal(response.headers.get('Service-Worker-Allowed'),'/');else if(file==='/index.html')assert.equal(response.headers.get('Content-Security-Policy'),'frame-ancestors '+app);
  }
  const before=assets.length;
  assert.equal((await worker.fetch(new Request(engine+'/api/runtime/',{method:'POST'}),{ORBIT_MODE:'engine',ORBIT_APP_ORIGIN:app,ASSETS})).status,405);
  assert.equal(assets.length,before);
  // Entry aliases do not intercept or weaken authenticated profile APIs.
  assert.equal((await worker.fetch(new Request(engine+'/api/context'),{ORBIT_MODE:'engine',ORBIT_APP_ORIGIN:app,ASSETS})).status,401);
});

test('opening the account entrypoint preserves an invitation and does not start an account before isolation',async()=>{
  const source=(await readFile(new URL('../src/entry.js',import.meta.url),'utf8')).replace('(async()=>{','globalThis.opening=(async()=>{');
  for(const path of ['/','/api/app']){
    const redirects=[],calls=[],context=vm.createContext({location:{pathname:path,search:'?view=browser',hash:'#invite=existing-invitation',origin:app,replace:url=>redirects.push(url)},navigator:{serviceWorker:{getRegistrations:async()=>{calls.push('registrations');return [];}}}});
    const entry=new vm.SourceTextModule(source,{context});await entry.link(specifier=>specifier.endsWith('.css')?new vm.SyntheticModule([],function(){},{context}):new vm.SyntheticModule(['initialiseAccount'],function(){this.setExport('initialiseAccount',async()=>calls.push('account'));},{context}));await entry.evaluate();await context.opening;
    if(path==='/'){assert.deepEqual(redirects,['/api/app?view=browser#invite=existing-invitation']);assert.deepEqual(calls,[]);}else{assert.deepEqual(redirects,[]);assert.deepEqual(calls,['registrations','account']);}
  }
});

test('Roblox app links offer only Orbit-contained routes and never become HTTP requests',async()=>{
  const {OrbitAppLinks:links}=await helpers();
  const native='roblox://experiences/start?placeId=86832525327994&joinAttemptId=example';
  const url=links.destination(engine+'/browse/'+encodeURIComponent(native));assert.equal(url.href,native);
  const page=links.response(url),html=await page.text();assert.equal(page.status,200);assert.equal(html.includes("CloudMoon"),false);assert.equal(html.includes("Try now.gg"),false);assert.match(html,/Roblox needs its app/);assert.match(html,/Return to Roblox in Orbit/);
  assert.equal(/target="_(blank|top)"|href="roblox:|href="roblox-player:/.test(html),false);
  assert.equal(html.includes('Try now.gg in Orbit'),false);assert.equal(html.includes('Unsupported protocol'),false);
  const cloud=html.match(/href="(\/browse\/[^"]+)"/)[1];assert.equal(cloud.includes('joinAttemptId'),false);assert.equal(cloud.includes('placeId'),false);
  assert.equal(page.headers.get('Cache-Control'),'no-store');assert.equal(page.headers.get('Referrer-Policy'),'no-referrer');assert.equal(page.headers.get('Cross-Origin-Embedder-Policy'),'require-corp');assert.match(page.headers.get('Content-Security-Policy'),/default-src 'none'/);
  assert.equal(links.response(new URL('https://www.roblox.com/')),null);assert.equal(links.destination(engine+'/api/context'),null);
  assert.equal((await links.response(new URL('javascript:alert(1)')).text()).includes('href='),false);
  assert.equal(links.response(url,false).status,400);
  const injected=await links.response(new URL('roblox://experiences/start?placeId=123&ticket='+encodeURIComponent('" onclick="alert(1)'))).text();assert.equal(injected.includes('" onclick="'),false);
});

test('site notices report real challenges and YouTube restrictions while allowing normal security-token retries',async()=>{
  const {OrbitSiteStatus:status}=await helpers();
  const event={url:new URL('https://www.youtube.com/watch?v=public'),destination:'iframe',status:200,responseHeaders:{},responseBody:'var ytInitialPlayerResponse = {"playabilityStatus":{"status":"LOGIN_REQUIRED","reason":"Sign in to confirm you’re not a bot"}};'};
  assert.equal(status.notice(event).type,'orbit-youtube-restricted');assert.equal(status.notice({...event,responseBody:'{"playabilityStatus":{"status":"OK"}}'}),null);
  assert.equal(status.notice({...event,url:new URL('https://unrelated.example/')}),null);
  const challenge={...event,url:new URL('https://neal.fun/password-game/'),status:403,responseHeaders:{'cf-mitigated':'challenge'}};assert.equal(status.notice(challenge).type,'orbit-site-challenge');assert.equal(challenge.status,403);
  const google=status.notice({...event,url:new URL('https://accounts.google.com/v3/signin/identifier'),responseBody:''});assert.equal(google.type,'orbit-google-signin');assert.equal(google.site,'accounts.google.com');
  const recovery={...event,destination:'',url:new URL('https://apis.roblox.com/account-recovery-service/v1/request-recovery'),status:403,responseHeaders:{'x-csrf-token':'private-token'}};assert.equal(status.notice(recovery),null);
  const blocked=status.notice({...recovery,responseHeaders:{'rblx-challenge-type':'captcha'}});assert.equal(blocked.type,'orbit-roblox-recovery-blocked');assert.equal(JSON.stringify(blocked).includes('private-token'),false);
});

test('Google GSI denial is explicit without leaking the sign-in URL or treating unrelated 403s as Google failures',async()=>{
  const {OrbitSiteStatus:status}=await helpers();
  const event={url:new URL('https://accounts.google.com/gsi/select?client_id=private-client&state=private-state'),destination:'iframe',status:403,responseHeaders:{},responseBody:'No access'};
  assert.deepEqual(JSON.parse(JSON.stringify(status.notice(event))),{type:'orbit-google-denied',site:'accounts.google.com'});
  assert.equal(status.notice({...event,status:200}).type,'orbit-google-signin');
  assert.equal(status.notice({...event,destination:'script'}),null);
  assert.equal(status.notice({...event,url:new URL('https://unrelated.example/gsi/select')}),null);
  assert.equal(status.notice({...event,url:new URL('https://accounts.google.com/unrelated')}),null);
});
