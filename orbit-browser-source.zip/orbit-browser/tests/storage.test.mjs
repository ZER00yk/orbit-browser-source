import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {JSDOM} from 'jsdom';
import {patchScramjetStorage} from '../scripts/scramjet-patches.mjs';

const upstream=await readFile(new URL('../node_modules/@mercuryworkshop/scramjet/dist/scramjet.all.js',import.meta.url),'utf8');
function installStorage(source,window){
  const context=vm.createContext({console:{warn(){}},URL,TextEncoder,TextDecoder,Event,EventTarget,performance,atob,btoa});
  context.self=context;
  vm.runInContext(source.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='),context);
  context.__testRequire(5289).default({url:new URL('https://pokerogue.net/')},window);
}
// These are the two settings-presence checks at the reported crash location.
function loadSettings(storage){
  if(!Object.hasOwn(storage,'settings'))return false;
  const settings=JSON.parse(storage.getItem('settings'));
  return Object.hasOwn(settings,'gameVersion');
}

test('real Scramjet storage reproduces the startup crash; patched storage skips missing settings',t=>{
  const broken=new JSDOM('',{url:'https://orbit.example/'}),fixed=new JSDOM('',{url:'https://orbit.example/'});
  t.after(()=>{broken.window.close();fixed.window.close();});
  installStorage(upstream,broken.window);
  assert.equal(Object.hasOwn(broken.window.localStorage,'settings'),true);
  assert.equal(broken.window.localStorage.getItem('settings'),null);
  assert.throws(()=>loadSettings(broken.window.localStorage),/Cannot convert undefined or null to object/);

  installStorage(patchScramjetStorage(upstream),fixed.window);
  for(const storage of [fixed.window.localStorage,fixed.window.sessionStorage]){
    assert.equal(Object.hasOwn(storage,'settings'),false);
    assert.equal(Object.getOwnPropertyDescriptor(storage,'settings'),undefined);
    assert.equal(loadSettings(storage),false);
  }
});

test('patched storage preserves existing settings, save data and site separation',t=>{
  const dom=new JSDOM('',{url:'https://orbit.example/'});t.after(()=>dom.window.close());
  const nativeLocal=dom.window.localStorage,nativeSession=dom.window.sessionStorage;
  const settings=JSON.stringify({gameVersion:'1.11.19',volume:75});
  nativeLocal.setItem('pokerogue.net@settings',settings);
  nativeLocal.setItem('pokerogue.net@data','existing game save');
  nativeLocal.setItem('other.example@settings','other website settings');
  nativeLocal.setItem('orbit-state','browser preferences');
  installStorage(patchScramjetStorage(upstream),dom.window);
  const storage=dom.window.localStorage;
  assert.equal(loadSettings(storage),true);
  assert.equal(storage.getItem('settings'),settings);
  assert.equal(Object.getOwnPropertyDescriptor(storage,'settings').value,settings);
  assert.equal(storage.getItem('data'),'existing game save');
  assert.deepEqual(Object.keys(storage).sort(),['data','settings']);
  storage.setItem('settings',JSON.stringify({gameVersion:'1.11.19',volume:50}));
  assert.equal(JSON.parse(nativeLocal.getItem('pokerogue.net@settings')).volume,50);
  assert.equal(nativeLocal.getItem('other.example@settings'),'other website settings');
  assert.equal(nativeLocal.getItem('orbit-state'),'browser preferences');
  storage.setItem('empty','');assert.equal(Object.hasOwn(storage,'empty'),true);
  storage.removeItem('settings');assert.equal(Object.hasOwn(storage,'settings'),false);
  dom.window.sessionStorage.setItem('settings',settings);
  assert.equal(nativeSession.getItem('pokerogue.net@settings'),settings);
  assert.equal(Object.hasOwn(dom.window.sessionStorage,'settings'),true);
});

test('the storage patch rejects an unexpected upstream bundle',()=>{
  assert.throws(()=>patchScramjetStorage('changed bundle'),/implementation changed/);
});
