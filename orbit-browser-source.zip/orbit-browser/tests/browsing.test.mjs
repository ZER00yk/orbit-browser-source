import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {JSDOM} from 'jsdom';
import * as model from '../src/model.js';
import {prepareServiceWorker} from '../src/service-worker.js';
import {sanitizeDiagnostics} from '../server/game-diagnostics.mjs';
import * as preferences from '../src/preferences.js';
import * as games from '../src/games.js';

const html=await fs.readFile(new URL('../index.html',import.meta.url),'utf8');
const source=(await fs.readFile(new URL('../src/main.js',import.meta.url),'utf8')).replace(/^import .+;\s*$/gm,'');
const tick=()=>new Promise(resolve=>setTimeout(resolve,15));
function launch(saved,{delay=0,settings}={}){
  const dom=new JSDOM(html,{url:'https://orbit.example/',runScripts:'outside-only',pretendToBeVisual:true});
  const {window}=dom;const frames=[],registered=[];
  Object.assign(window,model,preferences,games,{prepareServiceWorker,sanitizeDiagnostics});window.confirm=()=>true;
  window.fetch=async()=>({status:204});
  if(saved)window.localStorage.setItem(model.STORAGE_KEY,saved);
  if(settings)window.localStorage.setItem(preferences.PREFERENCES_KEY,JSON.stringify(settings));
  const registration={active:{}};
  const serviceWorker=Object.assign(new window.EventTarget(),{controller:registration.active,register:async()=>registration,ready:Promise.resolve(registration)});
  Object.defineProperty(window.navigator,'serviceWorker',{value:serviceWorker});
  class FakeFrame extends window.EventTarget{
    constructor(){super();this.frame=window.document.createElement('iframe');this.visited=[];}
    go(url){this.visited.push(url);this.frame.src='/browse/'+encodeURIComponent(url);const event=new window.Event('urlchange');event.url=url;this.dispatchEvent(event);this.frame.dispatchEvent(new window.Event('load'));}
    reload(){this.go(this.visited.at(-1));}
  }
  class FakeController extends window.EventTarget{
    async init(){if(delay)await new Promise(resolve=>setTimeout(resolve,delay));}
    async modifyConfig(config){window.lastEngineConfig=config;}
    createFrame(){const frame=new FakeFrame();frames.push(frame);return frame;}
  }
  window.RemoteController=FakeController;
  FakeController.prototype.check=async()=>true;
  window.BareMux={BareMuxConnection:class{async setTransport(){}}};
  window.WebSocket=class{
    constructor(){window.setTimeout(()=>this.onmessage?.({data:new Uint8Array([3,0,0,0,0,128,0,0,0]).buffer}),0);}
    close(){}
  };
  window.document.modelContext={registerTool:tool=>registered.push(tool)};
  window.accountNavigations=[];window.eval(source.replace('location.assign(url);','window.accountNavigations.push(url);'));
  const node=id=>window.document.getElementById(id);
  const submit=(id,address)=>{node(id==='home-search'?'home-address':'address').value=address;node(id).dispatchEvent(new window.Event('submit',{cancelable:true}));};
  return {dom,window,node,submit,frames,registered,saved:()=>window.localStorage.getItem(model.STORAGE_KEY)};
}

test('URL entry handles domains, ports, searches, and rejects executable URLs',()=>{
  assert.equal(model.resolveAddress('example.org:8443/path'),'https://example.org:8443/path');
  assert.equal(model.resolveAddress('example.org'),'https://example.org/');
  assert.equal(model.resolveAddress('cell biology','duckduckgo'),'https://duckduckgo.com/?q=cell%20biology');
  assert.throws(()=>model.resolveAddress('javascript:alert(1)'));
  assert.throws(()=>model.resolveAddress('https://user:secret@example.org/'));
});

test('pasting an Orbit invitation into its search box opens the actual account page and does not save or proxy the invite',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());const link='https://orbit.example/#invite='+'x'.repeat(43);app.submit('home-search',link);await tick();
  assert.deepEqual(app.window.accountNavigations,[link]);assert.equal(app.frames.length,0);assert.equal(app.saved()?.includes('invite='),false);
  const other='https://unrelated.example/#invite=someone-else';app.submit('home-search',other);await tick();assert.equal(app.frames[0].visited.at(-1),other);assert.deepEqual(app.window.accountNavigations,[link]);
});

test('fullscreen restores controls and keeps the running game iframe mounted',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());
  app.submit('home-search','pokerogue.net');await tick();
  const frame=app.frames[0].frame,document=app.window.document;let fullscreen=null,requests=0;
  Object.defineProperty(document,'fullscreenElement',{get:()=>fullscreen});
  document.documentElement.requestFullscreen=async()=>{requests++;fullscreen=document.documentElement;};
  document.exitFullscreen=async()=>{fullscreen=null;document.dispatchEvent(new app.window.Event('fullscreenchange'));};
  app.node('fullscreen-button').click();await tick();
  assert.equal(requests,1);assert.equal(app.node('app').classList.contains('controls-hidden'),true);
  assert.equal(app.node('restore-controls').hidden,false);assert.equal(frame.isConnected,true);
  assert.equal(app.frames[0].visited.length,1);
  document.dispatchEvent(new app.window.KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));await tick();
  assert.equal(app.node('app').classList.contains('controls-hidden'),false);assert.equal(app.node('restore-controls').hidden,true);
  assert.equal(fullscreen,null);assert.equal(app.node('frames').firstChild,frame);assert.equal(app.frames[0].visited.length,1);
});

test('saved display choices and history privacy preserve navigation and bookmarks',async t=>{
  const app=launch(null,{settings:{theme:'light',compact:true,showBookmarks:false,showStatus:false,saveHistory:false,restoreTabs:false}});t.after(()=>app.dom.window.close());
  assert.equal(app.window.document.documentElement.dataset.theme,'light');assert.equal(app.node('app').classList.contains('compact'),true);assert.equal(app.node('bookmark-bar').hidden,true);
  app.submit('home-search','example.org');await tick();app.node('bookmark-page').click();
  app.submit('address-form','example.net');await tick();assert.equal(app.node('back').disabled,false);
  app.node('back').click();await tick();assert.equal(app.node('address').value,'https://example.org/');
  const saved=JSON.parse(app.saved());assert.equal(saved.history.length,0);assert.equal(saved.bookmarks.length,1);assert.equal(saved.tabs.length,0);
  const restored=launch(app.saved(),{settings:{restoreTabs:false,saveHistory:false}});t.after(()=>restored.dom.window.close());
  assert.equal(restored.node('new-page').hidden,false);assert.equal(restored.node('bookmark-bar').querySelectorAll('.bookmark-chip').length,1);
});

test('ad-blocking choices reach the engine without reloading the game',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());app.submit('home-search','pokerogue.net');await tick();
  assert.equal(app.window.lastEngineConfig.orbitAdblock.enabled,true);
  app.node('site-ads').checked=true;app.node('site-ads').dispatchEvent(new app.window.Event('change'));
  assert.equal(app.window.lastEngineConfig.orbitAdblock.allowedSites[0],'pokerogue.net');assert.equal(app.frames[0].visited.length,1);
  assert.match(app.node('adblock-button').title,/paused/);
  const saved=JSON.parse(app.window.localStorage.getItem(preferences.PREFERENCES_KEY));assert.deepEqual(saved.allowedSites,['pokerogue.net']);
  app.node('adblock-enabled').checked=false;app.node('adblock-enabled').dispatchEvent(new app.window.Event('change'));
  assert.equal(app.window.lastEngineConfig.orbitAdblock.enabled,false);assert.equal(app.frames[0].visited.length,1);
});

test('bookmark, history, and selected tab survive a page refresh',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());
  app.submit('home-search','example.org');await tick();
  assert.equal(app.node('address').value,'https://example.org/');
  app.node('bookmark-page').click();
  app.node('new-tab').click();app.submit('home-search','www.wikipedia.org');await tick();
  const saved=JSON.parse(app.saved());assert.equal(saved.tabs.length,2);assert.equal(saved.bookmarks.length,1);assert.equal(saved.history.length,2);
  const restored=launch(app.saved());t.after(()=>restored.dom.window.close());await tick();
  assert.equal(restored.node('address').value,'https://www.wikipedia.org/');
  assert.equal(restored.node('bookmark-bar').querySelectorAll('.bookmark-chip').length,1);
  assert.equal(restored.node('tabs').children.length,2);
});

test('back and forward navigate correctly and a new address replaces forward history',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());
  for(const address of ['example.org','example.net','example.com']){app.submit('address-form',address);await tick();}
  app.node('back').click();await tick();assert.equal(app.node('address').value,'https://example.net/');
  app.node('forward').click();await tick();assert.equal(app.node('address').value,'https://example.com/');
  app.node('back').click();await tick();app.submit('address-form','www.wikipedia.org');await tick();assert.equal(app.node('forward').disabled,true);
});

test('rapid navigation during startup creates one frame and loads the latest address',async t=>{
  const app=launch(null,{delay:30});t.after(()=>app.dom.window.close());
  app.submit('home-search','example.org');app.submit('address-form','example.net');await new Promise(resolve=>setTimeout(resolve,60));
  assert.equal(app.frames.length,1);assert.deepEqual(app.frames[0].visited,['https://example.net/']);assert.equal(app.node('frames').children.length,1);
});

test('closing the last tab leaves a usable new tab',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());app.submit('home-search','example.org');await tick();
  app.node('tabs').querySelector('.tab-close').click();await tick();assert.equal(app.node('tabs').children.length,1);assert.equal(app.node('new-page').hidden,false);assert.equal(app.node('frames').children.length,0);
});

test('history search and delete use the saved state without corrupting bookmarks',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());app.submit('home-search','example.org');await tick();app.node('bookmark-page').click();
  // jsdom implements DOM interactions but not the native dialog UI.
  app.node('history-dialog').showModal=()=>{};app.node('history-dialog').close=()=>{};
  app.node('history-button').click();app.node('history-search').value='missing';app.node('history-search').dispatchEvent(new app.window.Event('input'));assert.match(app.node('history-list').textContent,/No websites match/);
  app.node('history-search').value='';app.node('history-search').dispatchEvent(new app.window.Event('input'));app.node('history-list').querySelector('.icon-button').click();const saved=JSON.parse(app.saved());assert.equal(saved.history.length,0);assert.equal(saved.bookmarks.length,1);
});

test('agent navigation shares the visible UI and rejects invalid input',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());const navigation=app.registered.find(tool=>tool.name==='navigate_browser_tab');
  await assert.rejects(()=>navigation.execute({address:'javascript:alert(1)'}));
  const result=await navigation.execute({address:'example.org'});assert.equal(result.url,'https://example.org/');assert.equal(app.node('address').value,result.url);
  const list=app.registered.find(tool=>tool.name==='list_browser_tabs').execute();assert.equal(list.activeId,result.tabId);
});

test('a stalled game exposes loading details without storing them in browsing history',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());
  app.submit('home-search','pokerogue.net');await tick();
  const report={stage:'stalled',scene:'loading',downloaded:700,processing:1,pending:[{type:'image',key:'pokemon_icons_3',state:16}]};
  app.window.__orbitGameDiagnostics({},report);
  assert.equal(app.node('game-loading-status').hidden,true);
  app.window.__orbitGameDiagnostics(app.frames[0].frame.contentWindow,report);
  assert.equal(app.node('game-loading-status').hidden,false);
  assert.match(app.node('game-details-text').textContent,/Pending image: pokemon_icons_3/);
  assert.equal(app.saved().includes('pokemon_icons_3'),false);
  app.node('settings-dialog').close=()=>{};app.node('game-details-dialog').showModal=()=>{};
  app.node('game-loading-status').click();
  app.window.__orbitGameDiagnostics(app.frames[0].frame.contentWindow,{stage:'complete',scene:'loading'});
  assert.equal(app.node('game-loading-status').hidden,true);
});

test('a real challenge notice stays in Orbit without disrupting its page or other tabs',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());
  app.submit('home-search','https://neal.fun/password-game/');await tick();
  const frame=app.frames[0].frame,serviceWorker=app.window.navigator.serviceWorker;
  const message=source=>{const event=new app.window.Event('message');Object.assign(event,{source,data:{type:'orbit-site-challenge',site:'neal.fun'}});serviceWorker.dispatchEvent(event);};
  message({});assert.equal(app.node('site-notice').hidden,true);
  app.window.dispatchEvent(new app.window.CustomEvent('orbit-engine-notice',{detail:{type:'orbit-site-challenge',site:'neal.fun'}}));
  assert.equal(app.node('site-notice').hidden,false);assert.equal(app.node('site-original'),null);
  assert.equal(frame.isConnected,true);assert.equal(app.frames[0].visited.length,1);
  app.node('new-tab').click();assert.equal(app.node('site-notice').hidden,true);
  app.node('tabs').firstChild.click();await tick();assert.equal(app.node('site-notice').hidden,false);
  app.node('dismiss-site-notice').click();assert.equal(app.node('site-notice').hidden,true);
});

test('real YouTube restrictions stay with their tab and BO1 has no obsolete storage warning',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());
  app.submit('home-search','https://www.youtube.com/watch?v=public');await tick();
  assert.equal(app.node('site-notice').hidden,true);
  app.window.dispatchEvent(new app.window.CustomEvent('orbit-engine-notice',{detail:{type:'orbit-youtube-restricted',site:'www.youtube.com'}}));
  assert.match(app.node('site-notice-message').textContent,/YouTube is asking you to sign in/);assert.equal(app.node('site-original'),null);
  app.node('new-tab').click();app.submit('home-search','https://vel.gg/bo1z');await tick();
  assert.equal(app.node('site-notice').hidden,true);assert.equal(app.node('site-notice-message').textContent,'');
  app.node('tabs').firstChild.click();await tick();assert.match(app.node('site-notice-message').textContent,/YouTube/);assert.equal(app.node('site-notice').hidden,false);
  assert.equal(app.saved().includes('orbit-youtube-restricted'),false);
});

test('Google sign-in notice keeps the service page in Orbit without an external sign-in option',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());
  app.submit('home-search','https://web.cloudmoonapp.com/game/com.roblox.client/');await tick();
  app.window.dispatchEvent(new app.window.CustomEvent('orbit-engine-notice',{detail:{type:'orbit-google-signin',site:'accounts.google.com'}}));
  assert.equal(app.node('site-notice').hidden,false);
  assert.match(app.node('site-notice-message').textContent,/Google sign-in is not finishing/);
  assert.equal(app.node('site-original'),null);
  app.window.dispatchEvent(new app.window.CustomEvent('orbit-engine-notice',{detail:{type:'orbit-google-denied',site:'accounts.google.com'}}));
  assert.match(app.node('site-notice-message').textContent,/Google denied this sign-in request \(403\)/);
  assert.match(app.node('site-notice-message').textContent,/email or username sign-in if it offers one/);
  assert.equal(app.node('site-original'),null);
});

test('an engine popup opens an Orbit tab and preserves the original game frame',async t=>{
  const app=launch();t.after(()=>app.dom.window.close());app.submit('home-search','https://game.example/');await tick();
  const popup=new app.window.Event('open-tab');popup.url='https://catalog.example/play';app.frames[0].dispatchEvent(popup);await tick();
  assert.equal(app.node('tabs').children.length,2);assert.equal(app.node('address').value,popup.url);
  assert.equal(app.frames[0].frame.isConnected,true);assert.deepEqual(app.frames[0].visited,['https://game.example/']);
  const empty=new app.window.Event('open-tab');empty.url='';app.frames[0].dispatchEvent(empty);await tick();
  assert.equal(app.node('tabs').children.length,2);assert.equal(app.node('address').value,popup.url);
});
