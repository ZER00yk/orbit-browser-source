import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {patchScramjetWorker} from '../scripts/scramjet-patches.mjs';
import {patchScramjetCookies} from '../scripts/scramjet-patches.mjs';

const upstream=await readFile(new URL('../node_modules/@mercuryworkshop/scramjet/dist/scramjet.all.js',import.meta.url),'utf8');
const config={prefix:'/browse/',files:{wasm:'/scram/scramjet.wasm.wasm'},orbitAdblock:{enabled:true,allowedSites:[]}};

// Run the shipped worker class, stubbing only its external I/O and rewriter.
// This preserves its real message handler and startup/fetch ordering.
function loadWorker(source,{initialize=async()=>{},persisted=config,cookies,readCookies=async()=>cookies,CookieStore=class{load(){}},timer=setTimeout,OrbitProfile}={}){
  const factory=source.match(/7510:function\(e,t,r\)\{([\s\S]*?)\},4110:function/);
  assert.ok(factory,'The pinned Scramjet worker module must be reviewed if it changes.');
  const listeners=new Map(),state={sharedConfig:undefined,wasmReady:false,initializations:0,configReads:0,requests:0};
  const modules={
    1403:{H:class{}},
    5790:{Pf:async function(){
      assert.ok(state.sharedConfig,'Shared proxy configuration must exist before rewriting a page.');
      assert.equal(state.wasmReady,true,'The rewriter must be ready before fetching a page.');
      state.requests++;
      return new Response('page ready');
    }},
    4110:{Ay:class{}},
    1561:{n$:async()=>{state.initializations++;await initialize();state.wasmReady=true;}},
    3831:{k:CookieStore},
    6570:{P2:async()=>({get:async store=>{if(store==='config'){state.configReads++;return persisted;}if(store==='cookies')return readCookies();}})},
    37:{Nk:value=>{state.sharedConfig=value;}},
    5956:{},
  };
  const require=id=>{assert.ok(id in modules,`Unexpected worker dependency ${id}`);return modules[id];};
  require.r=()=>{};
  require.d=(exports,definitions)=>{for(const [key,get] of Object.entries(definitions))Object.defineProperty(exports,key,{get});};
  const context=vm.createContext({OrbitProfile,EventTarget,setTimeout:timer,clearTimeout,addEventListener:(name,listener)=>listeners.set(name,listener),location:{origin:'https://orbit.example'},self:{clients:{get:async()=>({url:'https://orbit.example/'})}}});
  const exports={};
  vm.runInContext('(function(e,t,r){'+factory[1]+'})',context)({},exports,require);
  const worker=new exports.ScramjetServiceWorker();
  return {worker,state,message:value=>listeners.get('message')({data:{scramjet$type:'loadConfig',config:value}}),receive:data=>listeners.get('message')({data})};
}
const request={request:new Request('https://orbit.example/browse/'+encodeURIComponent('https://pokerogue.net/')),clientId:'orbit'};

test('upstream config messages reproduce the cold-worker startup failure',async()=>{
  const {worker,state,message}=loadWorker(upstream);
  await message(config);
  await worker.loadConfig();
  assert.equal(state.initializations,0);
  assert.equal(state.sharedConfig,undefined);
  await assert.rejects(worker.fetch(request),/Shared proxy configuration must exist/);
});

test('the patched worker initializes after an early config message before fetching',async()=>{
  const {worker,state,message}=loadWorker(patchScramjetWorker(upstream));
  await message(config);
  const response=await worker.fetch(request);
  assert.equal(await response.text(),'page ready');
  assert.equal(state.sharedConfig,config);
  assert.equal(state.initializations,1);
  assert.equal(state.configReads,0);
  assert.equal(state.requests,1);

  const nextConfig={...config,orbitAdblock:{enabled:false,allowedSites:['pokerogue.net']}};
  await message(nextConfig);
  await worker.fetch(request);
  assert.equal(worker.config.orbitAdblock.enabled,false);
  assert.equal(state.initializations,1,'Settings updates must not restart a ready engine.');
});

test('concurrent cold requests wait for a single rewriter initialization',async()=>{
  let release,started;
  const initializing=new Promise(resolve=>{started=resolve;});
  const gate=new Promise(resolve=>{release=resolve;});
  const {worker,state,message}=loadWorker(patchScramjetWorker(upstream),{initialize:()=>{started();return gate;}});
  await message(config);
  const first=worker.fetch(request),second=worker.fetch(request),loading=worker.loadConfig();
  await initializing;
  assert.equal(state.initializations,1);
  assert.equal(state.requests,0,'No page can reach rewriting before WASM is ready.');
  release();
  await Promise.all([first,second,loading]);
  assert.equal(state.initializations,1);
  assert.equal(state.requests,2);
});

test('worker restarts read persisted configuration and preserve the blocking policy',async()=>{
  const persisted={...config,orbitAdblock:{enabled:true,allowedSites:['pokerogue.net']}};
  const {worker,state}=loadWorker(patchScramjetWorker(upstream),{persisted});
  await Promise.all([worker.fetch(request),worker.fetch(request)]);
  assert.equal(state.configReads,1);
  assert.equal(state.sharedConfig,persisted);
  assert.equal(worker.config.orbitAdblock.allowedSites[0],'pokerogue.net');
  assert.equal(state.initializations,1);
  assert.equal(state.requests,2);
});

test('failed rewriter initialization can retry without fetching a partial page',async()=>{
  let attempts=0;
  const {worker,state,message}=loadWorker(patchScramjetWorker(upstream),{initialize:async()=>{if(++attempts===1)throw new Error('WASM download interrupted');}});
  await message(config);
  await assert.rejects(worker.fetch(request),/WASM download interrupted/);
  assert.equal(state.requests,0);
  assert.equal(await (await worker.fetch(request)).text(),'page ready');
  assert.equal(state.initializations,2);
  assert.equal(state.requests,1);
});

test('the startup patch rejects an unexpected upstream worker',()=>{
  assert.throws(()=>patchScramjetWorker('changed bundle'),/worker implementation changed/);
});

test('a page that misses a cookie message cannot hold requests forever; late acknowledgements are harmless',async()=>{
  const {worker,receive}=loadWorker(patchScramjetWorker(upstream),{timer:callback=>setTimeout(callback,10)});
  const messages=[],client={postMessage:message=>messages.push(message)};
  await worker.dispatch(client,{scramjet$type:'cookie',cookie:'session=current',url:'https://pokerogue.net/'});
  assert.equal(messages.length,1);
  assert.equal(Object.keys(worker.syncPool).length,0);
  await receive({scramjet$type:'cookie',scramjet$token:messages[0].scramjet$token});
  assert.equal(Object.keys(worker.syncPool).length,0);
});

test('a responsive page still acknowledges a cookie update before the request finishes',async()=>{
  const {worker,receive}=loadWorker(patchScramjetWorker(upstream));
  const client={postMessage:message=>queueMicrotask(()=>receive({scramjet$type:'cookie',scramjet$token:message.scramjet$token}))};
  await worker.dispatch(client,{scramjet$type:'cookie',cookie:'session=current',url:'https://pokerogue.net/'});
  assert.equal(Object.keys(worker.syncPool).length,0);
});

test('a restarted worker restores its real cookie jar before any page request',async()=>{
  const context=vm.createContext({URL,TextEncoder,TextDecoder,Event,EventTarget,performance,atob,btoa,console});context.self=context;
  const patched=patchScramjetCookies(patchScramjetWorker(upstream));
  vm.runInContext(patched.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='),context);
  const CookieStore=context.__testRequire(3831).k;
  const original=new CookieStore(),url=new URL('https://pokerogue.net/');
  original.setCookies(['pokerogue_sessionId=saved-session; Domain=pokerogue.net; Secure; Path=/'],url);
  const saved=JSON.parse(original.dump());
  let release;
  const gate=new Promise(resolve=>{release=resolve;});
  const {worker,state,message}=loadWorker(patched,{CookieStore,readCookies:()=>gate});
  await message(config);
  const pending=worker.fetch(request);
  await new Promise(resolve=>setImmediate(resolve));
  assert.equal(state.requests,0);
  release(saved);await pending;
  assert.equal(worker.cookieStore.getCookies(url,true),'pokerogue_sessionId=saved-session');
  assert.equal(state.requests,1);
});

test('the fully patched profile worker restores only its encrypted cookie jar before cold fetch',async()=>{
  const source=await readFile(new URL('../public/scram/scramjet.all.js',import.meta.url),'utf8');
  const cookieModule=source.match(/3831:function\(e,t,r\)\{([\s\S]*?)\},1014:function/);
  const cookieContext=vm.createContext({URL,console,TextEncoder,TextDecoder,Event,EventTarget,performance,atob,btoa});cookieContext.self=cookieContext;
  vm.runInContext(source.replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='),cookieContext);
  const CookieStore=cookieContext.__testRequire(3831).k;
  const saved={saved:{name:'session',value:'owner-session',domain:'pokerogue.net',path:'/'}};
  const profile={dbName:name=>'orbit:owner:'+name,cookieDump:value=>{assert.equal(value,'encrypted-owner-jar');return saved;}};
  const {worker,state}=loadWorker(source,{CookieStore,cookies:'encrypted-owner-jar',OrbitProfile:profile});await worker.fetch(request);
  assert.equal(worker.cookieStore.getCookies(new URL('https://pokerogue.net/'),true),'session=owner-session');assert.equal(state.requests,1);
});
