import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import fs from 'node:fs/promises';
import worker from '../server/worker.mjs';

const origin='https://profiles.example',app='https://orbit.example';
const channel='12345678-1234-1234-1234-123456789abc';
const source=await fs.readFile(new URL('../src/engine.js',import.meta.url),'utf8');
const workerSource=await fs.readFile(new URL('../src/service-worker.js',import.meta.url),'utf8');
async function launch({standalone=false,hash='#'+channel,configFailure=false,bootstrapStatus=200,contextStatus=200,isolated=true}={}){
  const messages=[],redirects=[],calls=[],listeners={},configured=[],navigated=[],controllers=[],intervals=[],frames=[],connections=[];
  const nodes={'engine-status':{hidden:false,textContent:'Opening your private browsing profile…'},'engine-open':{hidden:true,href:app},'engine-frames':{append(){}}};
  const active={scriptURL:origin+'/api/runtime/sw.js?v=11&profile=profile-one',postMessage(_data,ports){ports[0].postMessage({ok:true});}};
  const workers=new EventTarget();Object.assign(workers,{controller:active,ready:Promise.resolve({active}),register:async()=>({active})});
  class Channel {constructor(){this.port1={};this.port2={postMessage:data=>queueMicrotask(()=>this.port1.onmessage?.({data}))};}}
  class Scramjet extends EventTarget {constructor(config){super();controllers.push(config);}async init(){}async modifyConfig(){}createFrame(){const f=new EventTarget(),attributes={};frames.push(attributes);f.frame={setAttribute:(name,value)=>attributes[name]=value,addEventListener(){},remove(){}};f.go=url=>navigated.push(url);return f;}}
  const sandbox={console,URL,AbortSignal,EventTarget,Event,setTimeout,clearTimeout,setInterval(fn){intervals.push(fn);return 1;},MessageChannel:Channel,SharedArrayBuffer:isolated?SharedArrayBuffer:undefined,
    location:{hash,origin,replace:url=>redirects.push(url)},document:{getElementById:id=>nodes[id]},navigator:{serviceWorker:workers},
    isSecureContext:true,crossOriginIsolated:isolated,
    OrbitProfile:{configure:p=>configured.push(p),clearMemory(){}},$scramjetLoadController:()=>({ScramjetController:Scramjet}),
    BareMux:{BareMuxConnection:class {constructor(path){connections.push(path);}async setTransport(){}}},BroadcastChannel:class {postMessage(){}},
    addEventListener:(name,listener)=>listeners[name]=listener,
    fetch:async(path,options)=>{calls.push({path,options});if(path==='/api/config'){if(configFailure)throw new Error('Settings request failed');return Response.json({app});}if(path==='/api/bootstrap')return Response.json({id:'profile-one',key:'profile-key'},{status:bootstrapStatus});if(path==='/api/context')return Response.json({id:'profile-one'},{status:contextStatus});throw new Error('Unexpected fetch '+path);},
  };
  sandbox.window=sandbox;sandbox.parent=standalone?sandbox:{postMessage:(data,origin)=>messages.push({data,origin})};
  const context=vm.createContext(sandbox),entry=new vm.SourceTextModule(source.replace('openProfile().catch(startupError);','globalThis.opening=openProfile().catch(startupError);'),{context});
  await entry.link(async()=>new vm.SourceTextModule(workerSource,{context}));await entry.evaluate();await sandbox.opening;
  const message=data=>listeners.message({origin:app,source:sandbox.parent,data:{channel,...data}});
  return {messages,redirects,calls,nodes,configured,navigated,controllers,frames,connections,message,tick:()=>intervals[0](),setBootstrapStatus:value=>bootstrapStatus=value};
}
test('opening the published profile link directly returns to the Orbit account page',async()=>{
  for(const hash of ['', '#'+channel]){const run=await launch({standalone:true,hash});assert.deepEqual(run.redirects,[app]);assert.equal(run.nodes['engine-status'].textContent,'Opening Orbit…');assert.equal(run.messages.length,0);assert.equal(run.calls.length,1);}
});
test('an embedded profile starts only after the Orbit account page sends its ticket',async()=>{
  const run=await launch();assert.equal(run.messages[0].data.type,'ready');assert.equal(run.messages[0].origin,app);assert.equal(run.configured.length,0);
  await run.message({type:'init',ticket:'account-ticket',config:{}});assert.equal(run.configured[0].id,'profile-one');assert.equal(run.messages.at(-1).data.type,'started');assert.equal(run.calls[1].options.headers['X-Orbit-Ticket'],'account-ticket');
  await run.message({type:'go',url:'https://pokerogue.net/'});assert.deepEqual(run.navigated,['https://pokerogue.net/']);assert.equal(run.redirects.length,0);
  assert.match(run.frames[0].allow,/(?:^|; )cross-origin-isolated(?:;|$)/);
  assert.deepEqual(run.connections,['/api/runtime/connection.js']);
});
test('a rejected profile session shows a visible error and reports it to the account page',async()=>{
  const run=await launch({bootstrapStatus:401});await run.message({type:'init',ticket:'expired'});assert.equal(run.nodes['engine-status'].hidden,false);assert.match(run.nodes['engine-status'].textContent,/connection needs to be renewed/);assert.equal(run.nodes['engine-open'].hidden,false);assert.equal(run.messages.at(-1).data.type,'error');assert.equal(run.configured.length,0);
});
test('a secure browser without cross-origin isolation starts its authenticated profile and can navigate',async()=>{
  const run=await launch({isolated:false});await run.message({type:'init',ticket:'account-ticket'});assert.equal(run.messages.at(-1).data.type,'started');assert.equal(run.calls.length,2);assert.equal(run.configured[0].id,'profile-one');assert.equal(run.controllers[0].flags.syncxhr,false);
  await run.message({type:'go',url:'https://pokerogue.net/'});assert.deepEqual(run.navigated,['https://pokerogue.net/']);assert.equal(run.messages.some(m=>m.data.type==='error'),false);
  const expired=await launch({isolated:false,bootstrapStatus:401});await expired.message({type:'init',ticket:'expired'});assert.equal(expired.messages.at(-1).data.type,'error');assert.equal(expired.configured.length,0);
});
test('configuration failures and invalid embedded entry links leave a working Open Orbit link',async()=>{
  const failed=await launch({configFailure:true});assert.match(failed.nodes['engine-status'].textContent,/Settings request failed/);assert.equal(failed.nodes['engine-open'].hidden,false);
  const invalid=await launch({hash:''});assert.match(invalid.nodes['engine-status'].textContent,/from Orbit/);assert.equal(invalid.nodes['engine-open'].href,app);assert.equal(invalid.nodes['engine-open'].hidden,false);assert.equal(invalid.messages.length,0);
});
test('the account shell delegates browser isolation only to its configured engine',async()=>{
  const response=await worker.fetch(new Request(app+'/'),{ORBIT_ENGINE_ORIGIN:origin,ASSETS:{fetch:async()=>new Response('<html>Orbit</html>')}});
  assert.equal(response.headers.get('Permissions-Policy'),'cross-origin-isolated=(self "'+origin+'")');assert.equal(response.headers.get('Cross-Origin-Embedder-Policy'),'require-corp');assert.equal(response.headers.get('Cross-Origin-Opener-Policy'),'same-origin');
  assert.match(response.headers.get('Content-Security-Policy'),/frame-ancestors 'none'/);
});

test('a browsing cookie that expired during sleep renews while the existing game stays open',async()=>{
  const run=await launch({contextStatus:401});await run.message({type:'init',ticket:'first-ticket'});await run.message({type:'go',url:'https://pokerogue.net/'});
  await run.tick();assert.equal(run.messages.at(-1).data.type,'renew-session');assert.equal(run.messages.some(m=>m.data.type==='session-expired'),false);
  await run.message({type:'refresh',ticket:'renewed-ticket'});assert.equal(run.calls.at(-1).options.headers['X-Orbit-Ticket'],'renewed-ticket');assert.equal(run.configured.length,1);
  await run.message({type:'go',url:'https://pokerogue.net/'});assert.equal(run.navigated.length,2);
});
test('temporary renewal failures keep the same game active without a sign-in prompt',async()=>{
  const run=await launch({contextStatus:503});await run.message({type:'init',ticket:'first-ticket'});run.setBootstrapStatus(503);await run.tick();await run.message({type:'refresh',ticket:'renewed-ticket'});
  assert.equal(run.messages.some(m=>['error','session-expired'].includes(m.data.type)),false);await run.message({type:'go',url:'https://pokerogue.net/'});assert.equal(run.navigated.length,1);
});
