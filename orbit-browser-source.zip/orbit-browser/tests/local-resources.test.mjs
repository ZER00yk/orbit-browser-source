import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {MessagePort,MessageChannel,BroadcastChannel} from 'node:worker_threads';
import {JSDOM} from 'jsdom';
import {rewriteDynamicImports} from '../src/module-imports.js';

const engine='https://profiles.example',website='https://pokerogue.net/';
// Phaser's transparent 32 x 32 startup texture, loaded before game downloads.
const png='iVBORw0KGgoAAAANSUhEUgAAACAAAAAgAQMAAABJtOi3AAAAA1BMVEX///+nxBvIAAAAAXRSTlMAQObYZgAAABVJREFUeF7NwIEAAAAAgKD9qdeocAMAoAABm3DkcAAAAABJRU5ErkJggg==';
const bytes=Buffer.from(png,'base64'),data='data:image/png;base64,'+png;
const [bundle,wasm,sw,appLinks]=await Promise.all([
  '../public/scram/scramjet.all.js','../public/scram/scramjet.wasm.wasm','../public/sw.js','../public/app-links.js',
].map(path=>readFile(new URL(path,import.meta.url))));

// Exercise the shipped service-worker listener, app-link guard, URL encoder,
// and Scramjet's actual local-resource response handler. Only authentication
// I/O and the browser-owned blob registry are simulated; no relay is needed.
function proxy(){
  const dom=new JSDOM('',{url:engine,runScripts:'outside-only'}),w=dom.window,blobs=new Map(),fetched=[];
  Object.assign(w,{TextEncoder,TextDecoder,MessagePort,MessageChannel,BroadcastChannel,Request,Response,Headers,crossOriginIsolated:true,fetch:async(url,options)=>{
    fetched.push(String(url));
    if(String(url).startsWith('blob:')){assert.ok(blobs.has(String(url)));return blobs.get(String(url)).clone();}
    return fetch(url,options);
  }});
  w.WASM=wasm.toString('base64');
  w.eval(bundle.toString().replace('globalThis.$scramjetRequire=','globalThis.__testRequire=r,globalThis.$scramjetRequire='));
  w.eval(`new ($scramjetLoadController().ScramjetController)({prefix:'/browse/',files:{wasm:'/scram/scramjet.wasm.wasm',all:'/scram/scramjet.all.js',sync:'/scram/scramjet.sync.js'},flags:{syncxhr:false,sourcemaps:false}});`);
  w.OrbitProfile={bootstrap:()=>'',rewriteJS:rewriteDynamicImports};
  const encode=w.__testRequire(1472).Oy,localFetch=w.__testRequire(5790).Pf,listeners=new Map();
  let privateProfiles=0,proxyRequests=0;
  class ScramjetServiceWorker extends EventTarget{
    config={prefix:'/browse/',files:{wasm:'/scram/scramjet.wasm.wasm'}};
    cookieStore={};
    async loadConfig(){}
    route(){return true;}
    fetch(event){proxyRequests++;return localFetch.call(this,event.request);}
  }
  const context=vm.createContext({URL,Request,Response,Headers,DOMException,console,location:{origin:engine},importScripts(){},
    addEventListener:(name,listener)=>listeners.set(name,listener),
    $scramjetLoadWorker:()=>({ScramjetServiceWorker}),OrbitProfile:{configure(){privateProfiles++;}},
    fetch:async url=>{assert.equal(url,'/api/context');return Response.json({id:'private-account',key:'private-key'});},
  });context.self=context;
  vm.runInContext(appLinks.toString(),context);vm.runInContext(sw.toString(),context);
  return {blobs,fetched,stats:()=>({privateProfiles,proxyRequests}),close:()=>dom.window.close(),async request(url,destination){
    const address=new w.URL(website),request=new Request(encode(url,{base:address,origin:address}));
    Object.defineProperty(request,'destination',{value:destination});
    let response;listeners.get('fetch')({request,respondWith(value){response=value;}});
    assert.ok(response,'The local resource must be handled by the service worker.');return response;
  }};
}

test('PokéRogue startup data textures pass the real proxy route and retain their PNG bytes',async()=>{
  const run=proxy();try{
    const response=await run.request(data,'image');
    assert.equal(response.status,200);assert.equal(response.headers.get('Content-Type'),'image/png');
    assert.deepEqual(Buffer.from(await response.arrayBuffer()),bytes);
    assert.deepEqual(run.fetched,[data]);assert.deepEqual(run.stats(),{privateProfiles:1,proxyRequests:1});
  }finally{run.close();}
});

test('temporary image and graphics-worker blob URLs reach the local resource handler',async()=>{
  const run=proxy();try{
    run.blobs.set('blob:'+engine+'/texture',new Response(bytes,{headers:{'Content-Type':'image/png'}}));
    const image=await run.request('blob:https://pokerogue.net/texture','image');
    assert.equal(image.status,200);assert.deepEqual(Buffer.from(await image.arrayBuffer()),bytes);
    run.blobs.set('blob:'+engine+'/graphics',new Response('postMessage("graphics-ready");',{headers:{'Content-Type':'text/javascript'}}));
    const worker=await run.request('blob:https://pokerogue.net/graphics','worker');
    assert.equal(worker.status,200);assert.match(await worker.text(),/graphics-ready/);
    assert.deepEqual(run.fetched,['blob:'+engine+'/texture','blob:'+engine+'/graphics']);
    assert.deepEqual(run.stats(),{privateProfiles:1,proxyRequests:2});
  }finally{run.close();}
});

test('native Roblox app launches stay in Orbit and never reach the proxy resource handler',async()=>{
  const run=proxy();try{
    const page=await run.request('roblox://experiences/start?placeId=123','iframe');
    assert.equal(page.status,200);const html=await page.text();
    assert.match(html,/Return to Roblox in Orbit/);assert.equal(/target="_(blank|top)"/.test(html),false);
    const resource=await run.request('roblox://experiences/start?placeId=123','image');
    assert.equal(resource.status,400);
    assert.deepEqual(run.fetched,[]);assert.deepEqual(run.stats(),{privateProfiles:1,proxyRequests:0});
  }finally{run.close();}
});
