import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFile} from 'node:fs/promises';
import {sanitizeDiagnostics} from '../server/game-diagnostics.mjs';
import worker from '../server/worker.mjs';

test('startup diagnostics preserve loader work and identify stalled processing',async()=>{
  let now=0,poll;const reports=[];
  const window=new EventTarget();window.parent={__orbitGameDiagnostics:(source,report)=>reports.push(report)};
  class Loader{
    constructor(){this.scene={sys:{settings:{key:'loading'}}};this.queue={size:1,entries:[{type:'image',key:'pokemon_icons_3',state:16}]};this.list={size:0};this.inflight={size:0};this.totalComplete=700;this.totalFailed=0;this.events={};}
    once(name,fn){this.events[name]=fn;}
    nextFile(){this.calls=(this.calls||0)+1;return 'original result';}
  }
  const context=vm.createContext({window,Date:class extends Date{static now(){return now;}},setInterval:fn=>(poll=fn,1),clearInterval(){}});
  vm.runInContext(await readFile(new URL('../public/game-diagnostics.js',import.meta.url),'utf8'),context);
  window.Phaser={Loader:{LoaderPlugin:Loader}};
  const loader=new Loader();assert.equal(loader.nextFile(),'original result');assert.equal(loader.calls,1);
  poll();now=13001;poll();
  assert.equal(reports.at(-1).stage,'stalled');assert.equal(reports.at(-1).pending[0].key,'pokemon_icons_3');
  assert.equal(loader.queue.size,1);assert.equal(typeof loader.events.complete,'function');
  loader.events.complete();assert.equal(reports.at(-1).stage,'complete');
  const failure=new Event('unhandledrejection');failure.reason=new TypeError('Cannot read image data');window.dispatchEvent(failure);
  assert.equal(reports.at(-1).error.message,'Cannot read image data');
  const sourceError=new Event('error');sourceError.error=new TypeError('Cannot convert undefined or null to object');
  sourceError.error.stack='TypeError: Cannot convert undefined or null to object\n    at InputsController.setupKeyboard (https://orbit.example/browse/battle-scene.js:1:9000)';
  window.dispatchEvent(sourceError);
  assert.equal(reports.at(-1).error.frames[0],'InputsController.setupKeyboard @ battle-scene.js:1:9000');
});

test('reports remove private values and ignore unrelated fields',()=>{
  const report=sanitizeDiagnostics({stage:'error',cookie:'secret',token:'secret',error:{name:'TypeError',message:'token=private-secret user@example.org https://api.example/?access=private-secret',frames:['game.js:1:2']}});
  assert.equal('cookie' in report,false);assert.equal('token' in report,false);
  assert.equal(JSON.stringify(report).includes('private-secret'),false);assert.equal(JSON.stringify(report).includes('user@example.org'),false);
  assert.equal(sanitizeDiagnostics({stage:'other'}),null);
});

test('diagnostic reports require owner authentication and same-origin JSON',async t=>{
  const origin='https://orbit.example',url=origin+'/api/game-diagnostics';
  const base={method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify({stage:'stalled',scene:'loading',processing:1})};
  assert.equal((await worker.fetch(new Request(url,base),{})).status,401);
  assert.equal((await worker.fetch(new Request(url,{...base,headers:{...base.headers,'oai-authenticated-user-id':'test-user',Origin:'https://other.example'}}),{})).status,403);
  const original=console.warn;t.after(()=>console.warn=original);let logged;console.warn=(...args)=>logged=args.join(' ');
  const response=await worker.fetch(new Request(url,{...base,headers:{...base.headers,'oai-authenticated-user-id':'test-user'}}),{});
  assert.equal(response.status,204);assert.match(logged,/ORBIT_GAME_DIAGNOSTICS/);assert.match(logged,/"processing":1/);
});
