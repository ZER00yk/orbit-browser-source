import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import fs from 'node:fs/promises';
import {JSDOM} from 'jsdom';
import {gcm} from '@noble/ciphers/aes.js';
import {accountRoutes} from '../server/accounts.mjs';
import {token,hash,profileKey,verifyTicket} from '../server/account-crypto.mjs';
import {engineRoutes,engineContext} from '../server/engine-auth.mjs';
const origin='https://orbit.example',engine='https://profiles.example',password='a long personal passphrase 123';
function database(){
  const sql=new DatabaseSync(':memory:');sql.exec('PRAGMA foreign_keys=ON');
  return {sql,prepare(query){const statement=sql.prepare(query);let args=[];return {bind(...values){args=values;return this;},async first(){return statement.get(...args)||null;},async run(){return statement.run(...args);}};},async batch(statements){sql.exec('BEGIN');try{const result=[];for(const statement of statements)result.push(await statement.run());sql.exec('COMMIT');return result;}catch(error){sql.exec('ROLLBACK');throw error;}}};
}
async function fixture(){const DB=database();for(const file of (await fs.readdir(new URL('../drizzle/',import.meta.url))).filter(name=>name.endsWith('.sql')).sort())DB.sql.exec(await fs.readFile(new URL('../drizzle/'+file,import.meta.url),'utf8'));const setup=token();const env={DB,ORBIT_ENGINE_ORIGIN:engine,ORBIT_TICKET_SECRET:token(),ORBIT_PROFILE_SECRET:token(),ORBIT_SETUP_HASH:hash(setup)};
  const call=(path,{method='GET',data,cookie='',from=origin,ip='test'}={})=>accountRoutes(new Request(origin+'/api/'+path,{method,headers:{Origin:from,Cookie:cookie,'CF-Connecting-IP':ip,...data&&{'Content-Type':'application/json'}},body:data&&JSON.stringify(data)}),env);
  const create=async(username,code,path='register')=>call(path,{method:'POST',data:{username,password,code}});
  const ownerResponse=await create('owner',setup,'setup');assert.equal(ownerResponse.status,200);const owner=await ownerResponse.json();const ownerCookie=ownerResponse.headers.get('Set-Cookie').split(';')[0];
  const invite=await (await call('invites',{method:'POST',cookie:ownerCookie,data:{}})).json();
  return {DB,env,setup,call,create,ownerCookie,owner,code:new URL(invite.url).hash.slice(8)};
}
const accountHTML=await fs.readFile(new URL('../index.html',import.meta.url),'utf8');
const accountScript=(await fs.readFile(new URL('../src/account.js',import.meta.url),'utf8')).replace(/^import .+;\s*$/gm,'').replaceAll('export ','').replace("await import('./main.js')","await window.startBrowser()");
async function accountPage(f,url,cookie=''){
  const dom=new JSDOM(accountHTML,{url,runScripts:'outside-only'}),w=dom.window,calls=[];let starts=0;
  Object.assign(w,{TextEncoder,TextDecoder,gcm});w.startBrowser=async()=>{starts++;};
  w.fetch=async(path,options={})=>{
    calls.push({path,method:options.method||'GET'});
    const response=await accountRoutes(new Request(new URL(path,w.location.href),{...options,headers:{...options.headers,Origin:w.location.origin,Cookie:cookie,'CF-Connecting-IP':'browser-test'}}),f.env);
    const setCookie=response.headers.get('Set-Cookie');if(setCookie)cookie=setCookie.split(';')[0];return response;
  };
  w.eval(accountScript);await w.initialiseAccount();
  return {dom,w,calls,starts:()=>starts,node:id=>w.document.getElementById(id),cookie:()=>cookie};
}
test('the owner-generated invitation survives a refresh and the real form creates a new private member account',async t=>{
  const f=await fixture();t.after(()=>f.DB.sql.close());const link=origin+'/#invite='+f.code,first=await accountPage(f,link);t.after(()=>first.dom.window.close());
  assert.equal(first.node('account-heading').textContent,'Create your Orbit account');assert.equal(first.node('account-submit').textContent,'Create account');assert.equal(first.w.location.href,link);
  const refreshed=await accountPage(f,first.w.location.href);t.after(()=>refreshed.dom.window.close());assert.equal(refreshed.node('account-submit').textContent,'Create account');
  refreshed.node('account-username').value='new-invited-person';refreshed.node('account-password').value=password;await refreshed.node('account-form').onsubmit(new refreshed.w.Event('submit',{cancelable:true}));
  assert.equal(refreshed.node('account-message').textContent,'');assert.equal(refreshed.node('account-gate').hidden,true);assert.equal(refreshed.w.currentAccount().username,'new-invited-person');assert.equal(refreshed.w.currentAccount().role,'member');assert.equal(refreshed.starts(),1);assert.equal(refreshed.w.location.hash,'');assert.equal(refreshed.calls.some(call=>call.path==='/api/login'),false);assert.ok(refreshed.calls.some(call=>call.path==='/api/register'));assert.equal((await f.create('reuse-this',f.code)).status,403);
});
test('failed registration keeps its invitation and signed-in visitors see account creation without being switched automatically',async t=>{
  const f=await fixture();t.after(()=>f.DB.sql.close());const page=await accountPage(f,origin+'/#invite='+f.code,f.ownerCookie);t.after(()=>page.dom.window.close());
  assert.equal(page.node('account-submit').textContent,'Create account');assert.equal(page.node('account-existing').hidden,false);assert.equal(page.node('account-existing-name').textContent,'owner');assert.equal(page.starts(),0);assert.equal(page.cookie(),f.ownerCookie);
  page.node('account-username').value='not-an@email';page.node('account-password').value=password;await page.node('account-form').onsubmit(new page.w.Event('submit',{cancelable:true}));
  assert.match(page.node('account-message').textContent,/username/i);assert.equal(page.w.location.hash,'#invite='+f.code);assert.equal(page.node('account-submit').textContent,'Create account');assert.equal(page.cookie(),f.ownerCookie);assert.equal((await f.call('account',{cookie:f.ownerCookie})).status,200);
});
test('a normal visit still restores an existing remembered account while an anonymous visit shows Sign in',async t=>{
  const f=await fixture();t.after(()=>f.DB.sql.close());const signed=await accountPage(f,origin+'/',f.ownerCookie),anonymous=await accountPage(f,origin+'/');t.after(()=>{signed.dom.window.close();anonymous.dom.window.close();});
  assert.equal(signed.node('account-gate').hidden,true);assert.equal(signed.w.currentAccount().user?.username||signed.w.currentAccount().username,'owner');assert.equal(signed.starts(),1);assert.equal(anonymous.node('account-gate').hidden,false);assert.equal(anonymous.node('account-submit').textContent,'Sign in');
});
test('owner setup requires a secret and cannot be repeated or won by an anonymous first visitor',async()=>{
  const f=await fixture();assert.equal((await f.create('attacker',token(),'setup')).status,403);assert.equal((await f.create('second-owner',f.setup,'setup')).status,403);assert.equal((await f.create('uninvited',token())).status,403);
  assert.equal(f.DB.sql.prepare("SELECT count(*) AS n FROM users WHERE role='owner'").get().n,1);f.DB.sql.close();
});
test('a one-use invitation creates a member whose profile and sessions cannot access the owner',async()=>{
  const f=await fixture(),response=await f.create('friend',f.code);assert.equal(response.status,200);const member=await response.json(),cookie=response.headers.get('Set-Cookie').split(';')[0];
  assert.equal(member.user.role,'member');assert.equal((await f.create('reuse',f.code)).status,403);assert.equal((await f.call('invites',{method:'POST',cookie,data:{}})).status,403);
  const ownerCipher='v1.'+Buffer.from('encrypted-owner-profile').toString('base64url');await f.call('profile',{method:'PUT',cookie:f.ownerCookie,data:{cipher:ownerCipher,userId:f.owner.user.id}});
  assert.equal((await(await f.call('profile',{cookie})).json()).cipher,null);
  const friendCipher='v1.'+Buffer.from('encrypted-friend-profile').toString('base64url');assert.equal((await f.call('profile',{method:'PUT',cookie,data:{cipher:friendCipher,userId:f.owner.user.id}})).status,409);await f.call('profile',{method:'PUT',cookie,data:{cipher:friendCipher,userId:member.user.id}});
  assert.equal((await(await f.call('profile',{cookie:f.ownerCookie})).json()).cipher,ownerCipher);
  const a=await(await f.call('account',{cookie:f.ownerCookie})).json(),b=await(await f.call('account',{cookie})).json();assert.notEqual(a.key,b.key);assert.equal(b.key,profileKey(member.user.id,f.env.ORBIT_PROFILE_SECRET));
  assert.equal((await f.call('profile')).status,401);f.DB.sql.close();
});
test('passwords and session tokens are stored as salted hashes; CSRF and forged cookies fail',async()=>{
  const f=await fixture(),row=f.DB.sql.prepare('SELECT password FROM users').get();assert.match(row.password,/^scrypt:16384:8:5:/);assert.equal(row.password.includes(password),false);
  const raw=f.ownerCookie.split('=')[1],session=f.DB.sql.prepare('SELECT hash FROM sessions').get();assert.equal(session.hash,hash(raw));assert.equal(session.hash.includes(raw),false);
  assert.equal((await f.call('logout',{method:'POST',cookie:f.ownerCookie,data:{},from:engine})).status,403);
  assert.equal((await f.call('profile',{cookie:'__Host-orbit-session='+token()})).status,401);
  assert.equal((await f.call('login',{method:'POST',data:{username:'owner',password:'incorrect long password'}})).status,401);
  const login=await f.call('login',{method:'POST',data:{username:'owner',password}});assert.equal(login.status,200);assert.match(login.headers.get('Set-Cookie'),/HttpOnly; Secure; SameSite=Strict/);f.DB.sql.close();
});
test('engine tickets bind the account, origin and active session; logout invalidates them',async()=>{
  const f=await fixture(),{ticket}=await(await f.call('engine-ticket',{method:'POST',cookie:f.ownerCookie,data:{}})).json();
  assert.ok(verifyTicket(ticket,f.env.ORBIT_TICKET_SECRET,{issuer:origin,audience:engine}));assert.equal(verifyTicket(ticket,f.env.ORBIT_TICKET_SECRET,{issuer:origin,audience:origin}),null);assert.equal(verifyTicket(ticket+'x',f.env.ORBIT_TICKET_SECRET,{issuer:origin,audience:engine}),null);
  const request=()=>f.call('engine-authorize',{method:'POST'});
  const authorize=()=>accountRoutes(new Request(origin+'/api/engine-authorize',{method:'POST',headers:{Authorization:'Bearer '+ticket}}),f.env);
  assert.equal((await authorize()).status,200);await f.call('logout',{method:'POST',cookie:f.ownerCookie,data:{}});assert.equal((await authorize()).status,401);assert.equal((await f.call('profile',{cookie:f.ownerCookie})).status,401);f.DB.sql.close();
});
test('expired invitations and sessions are rejected and repeated password guesses are throttled',async()=>{
  const f=await fixture();f.DB.sql.prepare('UPDATE invites SET expires=0').run();assert.equal((await f.create('expired',f.code)).status,403);
  f.DB.sql.prepare('UPDATE sessions SET expires=0').run();assert.equal((await f.call('account',{cookie:f.ownerCookie})).status,401);
  let response;for(let i=0;i<16;i++)response=await f.call('login',{method:'POST',data:{username:'missing',password:'a wrong but long password'},ip:'abuse'});assert.equal(response.status,429);f.DB.sql.close();
});

test('remembered accounts restore across visits and renew without a password while temporary sessions stay temporary',async()=>{
  const f=await fixture(),raw=f.ownerCookie.split('=')[1],sid=hash(raw),now=Date.now();
  let session=f.DB.sql.prepare('SELECT expires,remembered FROM sessions WHERE hash=?').get(sid);
  assert.equal(session.remembered,1);assert.ok(session.expires>=now+364*86400000);
  f.DB.sql.prepare('UPDATE sessions SET expires=? WHERE hash=?').run(now+3600000,sid);
  const restored=await f.call('account',{cookie:f.ownerCookie});assert.equal(restored.status,200);assert.equal((await restored.json()).user.id,f.owner.user.id);assert.match(restored.headers.get('Set-Cookie'),/Max-Age=31536000/);assert.ok(restored.headers.get('Set-Cookie').startsWith(f.ownerCookie+';'));
  session=f.DB.sql.prepare('SELECT expires FROM sessions WHERE hash=?').get(sid);assert.ok(session.expires>=now+364*86400000);
  f.DB.sql.prepare('UPDATE sessions SET expires=? WHERE hash=?').run(now+3600000,sid);
  const renewed=await f.call('engine-ticket',{method:'POST',cookie:f.ownerCookie,data:{}});assert.equal(renewed.status,200);assert.match(renewed.headers.get('Set-Cookie'),/Max-Age=31536000/);
  const temporary=await f.call('login',{method:'POST',data:{username:'owner',password,remember:false}});const temporaryCookie=temporary.headers.get('Set-Cookie').split(';')[0];assert.match(temporary.headers.get('Set-Cookie'),/Max-Age=43200/);
  const tempSid=hash(temporaryCookie.split('=')[1]);assert.equal(f.DB.sql.prepare('SELECT remembered FROM sessions WHERE hash=?').get(tempSid).remembered,0);
  f.DB.sql.prepare('UPDATE sessions SET expires=? WHERE hash=?').run(now+3600000,tempSid);const tempRestored=await f.call('account',{cookie:temporaryCookie});assert.equal(tempRestored.status,200);assert.equal(tempRestored.headers.has('Set-Cookie'),false);
  f.DB.sql.prepare('UPDATE sessions SET expires=0 WHERE hash=?').run(sid);assert.equal((await f.call('account',{cookie:f.ownerCookie})).status,401);f.DB.sql.close();
});

test('a connection failure preserves account sign-in and is reported as unavailable rather than expired',async()=>{
  const f=await fixture(),{ticket}=await(await f.call('engine-ticket',{method:'POST',cookie:f.ownerCookie,data:{}})).json(),original=globalThis.fetch;
  try{
    globalThis.fetch=async(_url,init)=>{assert.equal(init.redirect,'manual');return Response.json({error:'Unavailable'},{status:503});};
    const response=await engineRoutes(new Request(engine+'/api/bootstrap',{method:'POST',headers:{Origin:engine,'X-Orbit-Ticket':ticket}}),{ORBIT_APP_ORIGIN:origin});assert.equal(response.status,503);assert.doesNotMatch((await response.json()).error,/sign in|session expired/i);assert.equal((await f.call('account',{cookie:f.ownerCookie})).status,200);
  }finally{globalThis.fetch=original;f.DB.sql.close();}
});

test('the engine uses the account server to validate tickets and rejects anonymous, forged and revoked sessions',async()=>{
  const f=await fixture(),{ticket}=await(await f.call('engine-ticket',{method:'POST',cookie:f.ownerCookie,data:{}})).json();const env={ORBIT_APP_ORIGIN:origin};const original=globalThis.fetch;globalThis.fetch=async(url,init)=>{const headers=new Headers(init.headers);headers.delete('Authorization');return accountRoutes(new Request(url,{...init,headers}),f.env);};
  try{
    const boot=async(from,value)=>engineRoutes(new Request(engine+'/api/bootstrap',{method:'POST',headers:{Origin:from,Authorization:'Bearer '+value}}),env);
    assert.equal((await boot(origin,ticket)).status,403);assert.equal((await boot(engine,'bad')).status,401);const [payload]=ticket.split('.');assert.equal((await boot(engine,payload+'.'+token())).status,401);const response=await boot(engine,ticket);assert.equal(response.status,200);assert.match(response.headers.get('Set-Cookie'),/HttpOnly; Secure; SameSite=None; Partitioned/);const context=await response.json();assert.equal(context.id,f.owner.user.id);
    assert.equal((await engineRoutes(new Request(engine+'/api/bootstrap',{method:'POST',headers:{Origin:engine,'X-Orbit-Ticket':ticket}}),env)).status,200);
    const request=new Request(engine+'/wisp/',{headers:{Cookie:response.headers.get('Set-Cookie').split(';')[0]}});assert.equal((await engineContext(request,env)).id,f.owner.user.id);
    await f.call('logout',{method:'POST',cookie:f.ownerCookie,data:{}});assert.equal(await engineContext(request,env),null);
  }finally{globalThis.fetch=original;f.DB.sql.close();}
});
