# Third-party software

- Scramjet 1.1.0 — https://github.com/MercuryWorkshop/scramjet — MIT
- bare-mux 2.1.9 — https://github.com/MercuryWorkshop/bare-mux — AGPL-3.0
- libcurl-transport 2.0.5 — https://github.com/MercuryWorkshop/CurlTransport — AGPL-3.0
- libcurl.js — https://github.com/ading2210/libcurl.js — consult upstream bundled third-party notices
- Wisp JavaScript 0.4.1 — https://github.com/MercuryWorkshop/wisp-js — AGPL-3.0
- Peter Lowe’s ad and tracking server list — https://pgl.yoyo.org/adservers/ — free redistribution and combination permitted by the source page. Snapshot updated September 27, 2026; the original credits and source URL are retained in `public/adblock-hosts.txt`.

Exact installed dependency versions are recorded in package-lock.json. The original source maps accompany the browser bundles. The interface and deployment source are kept in the Site source repository.

Orbit applies small storage property-descriptor, worker startup-readiness, and cookie restoration/delivery/persistence corrections to Scramjet's browser bundle. The patch source is `scripts/scramjet-patches.mjs` in the Site repository; the upstream dependency and license remain unchanged.

Orbit exports libcurl-transport's existing bundled libcurl API through `scripts/libcurl-patches.mjs`. The adapter in `public/wisp-dns.mjs` can supply a fresh public DNS address after an unreachable-host response from Wisp. It retains the original TLS server name and certificate verification; the compiled TLS library is unchanged.
