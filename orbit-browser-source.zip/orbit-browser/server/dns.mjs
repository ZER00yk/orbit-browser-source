import {publicHostname,publicIPv4} from '../public/dns-policy.mjs';

export async function dnsResponse(request){
  const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
  if(request.method!=='GET')return new Response('GET required',{status:405,headers:{...headers,Allow:'GET'}});
  const hostname=new URL(request.url).searchParams.get('hostname');
  if(!publicHostname(hostname))return new Response('Invalid public hostname',{status:400,headers});
  let stage='fetch',status,dnsStatus;
  try{
    const resolver=new URL('https://dns.google/resolve');
    resolver.searchParams.set('name',hostname);resolver.searchParams.set('type','A');
    // Do not send Orbit cookies, account tickets or a client subnet to DNS.
    resolver.searchParams.set('edns_client_subnet','0.0.0.0/0');
    const response=await fetch(resolver.href,{headers:{Accept:'application/json'},redirect:'manual',signal:AbortSignal.timeout(5000)});
    status=response.status;
    if(!response.ok)throw new Error('DNS unavailable');
    stage='answer';
    const data=await response.json();
    dnsStatus=Number.isInteger(data.Status)?data.Status:undefined;
    if(data.Status!==0||data.TC||!Array.isArray(data.Answer))throw new Error('DNS unavailable');
    const answers=data.Answer.filter(answer=>answer.type===1&&publicIPv4(answer.data)&&Number.isFinite(answer.TTL)&&answer.TTL>=1);
    const addresses=[...new Set(answers.map(answer=>answer.data))].slice(0,8);
    if(!addresses.length)throw new Error('No public address');
    const ttl=Math.min(300,...data.Answer.filter(answer=>[1,5].includes(answer.type)&&Number.isFinite(answer.TTL)).map(answer=>answer.TTL));
    if(ttl<1)throw new Error('Expired DNS answer');
    return Response.json({hostname,addresses,ttl},{headers});
  }catch(error){
    // Report connection details without recording the visited hostname,
    // account credentials, DNS answer or browsing data.
    console.warn('ORBIT_DNS_UNAVAILABLE',JSON.stringify({stage,status,dnsStatus,code:error.name,message:String(error.message).replace(/https?:\/\/\S+/g,'[resolver]').slice(0,160)}));
    return new Response('Hostname lookup unavailable',{status:502,headers});
  }
}
