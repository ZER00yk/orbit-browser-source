import {scrypt,randomBytes,createHash,createHmac,timingSafeEqual} from 'node:crypto';
export const token=()=>randomBytes(32).toString('base64url');
export const hash=value=>createHash('sha256').update(value).digest('hex');
export function equal(a,b){const x=Buffer.from(String(a)),y=Buffer.from(String(b));return x.length===y.length&&timingSafeEqual(x,y);}
export async function passwordHash(password,salt=token()){
  const key=await new Promise((resolve,reject)=>scrypt(password,salt,32,{N:16384,r:8,p:5,maxmem:32*1024*1024},(error,value)=>error?reject(error):resolve(value)));
  return `scrypt:16384:8:5:${salt}:${key.toString('base64url')}`;
}
export async function passwordMatches(password,stored){
  if(typeof stored!=='string'||!stored.startsWith('scrypt:16384:8:5:'))return false;
  return equal(await passwordHash(password,stored.split(':')[4]),stored);
}
export function signTicket(payload,secret){
  const body=Buffer.from(JSON.stringify(payload)).toString('base64url');
  return body+'.'+createHmac('sha256',secret).update(body).digest('base64url');
}
export function verifyTicket(value,secret,{issuer,audience,now=Date.now()}={}){
  if(typeof value!=='string'||value.length>2000||!secret)return null;
  const [body,signature,extra]=value.split('.');if(extra||!body||!signature)return null;
  if(!equal(createHmac('sha256',secret).update(body).digest('base64url'),signature))return null;
  try{const p=JSON.parse(Buffer.from(body,'base64url').toString());
    if(p.iss!==issuer||p.aud!==audience||!Number.isSafeInteger(p.exp)||p.exp<=now||p.exp>now+11*60*1000||!/^[-\w]{20,60}$/.test(p.sub)||! /^[a-f0-9]{64}$/.test(p.sid))return null;
    return p;
  }catch{return null;}
}
export const profileKey=(id,secret)=>createHmac('sha256',secret).update('orbit-profile-v1:'+id).digest('base64url');
