export function sanitizeDiagnostics(input){
  if(!input||!['starting','stalled','complete','error'].includes(input.stage))return null;
  const clean=(value,max=120)=>String(value||'').replace(/https?:\/\/\S+/gi,'[URL]').replace(/[\w.+-]+@[\w.-]+\.[a-z]{2,}/gi,'[email]').replace(/(?:token|password|authorization|cookie)\s*[:=]\s*\S+/gi,'[private value]').replace(/[a-z0-9_=-]{28,}/gi,'[value]').slice(0,max);
  const result={game:'pokerogue.net',stage:input.stage,scene:clean(input.scene,40)};
  for(const key of ['downloaded','failed','waiting','downloading','processing'])if(Number.isFinite(input[key]))result[key]=Math.max(0,Math.min(100000,input[key]));
  if(Array.isArray(input.pending))result.pending=input.pending.slice(0,12).map(file=>({type:clean(file?.type,20),key:clean(file?.key,100),state:Number(file?.state)||0}));
  if(input.error)result.error={name:clean(input.error.name,40),message:clean(input.error.message,240),frames:(Array.isArray(input.error.frames)?input.error.frames:[]).slice(0,4).map(frame=>clean(frame,100))};
  return result;
}
