import {sanitizeDiagnostics} from './game-diagnostics.mjs';
import {accountRoutes,authenticate} from './accounts.mjs';
import {engineRoutes,engineContext} from './engine-auth.mjs';
import {dnsResponse} from './dns.mjs';
const DEFAULT_RELAY='https://wisp.mercurywork.shop/';
const securityHeaders={
  'Cross-Origin-Opener-Policy':'same-origin',
  'Cross-Origin-Embedder-Policy':'require-corp',
  'Cross-Origin-Resource-Policy':'same-origin',
  'X-Content-Type-Options':'nosniff',
  'Referrer-Policy':'no-referrer',
};
export default {
  async fetch(request,env) {
    const url=new URL(request.url);
    const engine=env.ORBIT_MODE==='engine';
    // Sites serves matching static assets before this Worker. Use explicit
    // dynamic entrypoints so document and worker isolation headers actually
    // reach the browser, including every ancestor of a proxied game frame.
    const entry=engine&&url.pathname==='/api/runtime/'?'/index.html':
      engine&&url.pathname==='/api/runtime/sw.js'?'/sw.js':
      engine&&url.pathname==='/api/runtime/connection.js'?'/baremux/worker.js':
      !engine&&env.ORBIT_ENGINE_ORIGIN&&url.pathname==='/api/app'?'/index.html':null;
    if(entry){
      if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405,headers:{Allow:'GET, HEAD'}});
      if(!env.ASSETS)return new Response('Site assets unavailable',{status:503});
      const asset=new URL(entry,url.origin);
      const response=await env.ASSETS.fetch(new Request(asset,{method:request.method}));
      const headers=new Headers(response.headers);
      for(const [name,value]of Object.entries(securityHeaders))headers.set(name,value);
      headers.set('Cache-Control','no-store');
      if(engine){
        headers.set('Cross-Origin-Resource-Policy','cross-origin');
        if(entry==='/index.html')headers.set('Content-Security-Policy',`frame-ancestors ${env.ORBIT_APP_ORIGIN}`);
        if(entry==='/sw.js')headers.set('Service-Worker-Allowed','/');
      }else{
        headers.set('Permissions-Policy',`cross-origin-isolated=(self "${env.ORBIT_ENGINE_ORIGIN}")`);
        headers.set('Content-Security-Policy',`default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src ${env.ORBIT_ENGINE_ORIGIN}; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'`);
      }
      return new Response(response.body,{status:response.status,statusText:response.statusText,headers});
    }
    if(url.pathname==='/api/dns'){
      if(!engine&&env.ORBIT_ENGINE_ORIGIN)return new Response('Use the browsing engine',{status:404});
      if(!(engine?await engineContext(request,env):request.headers.get('oai-authenticated-user-id')))
        return new Response('Sign in required',{status:401,headers:securityHeaders});
      return dnsResponse(request);
    }
    if(engine){const response=await engineRoutes(request,env);if(response)return response;}
    else if(env.ORBIT_ENGINE_ORIGIN){const response=await accountRoutes(request,env);if(response)return response;}
    if(url.pathname==='/api/game-diagnostics'){
      const signedIn=engine?await engineContext(request,env):env.ORBIT_ENGINE_ORIGIN?await authenticate(request,env):request.headers.get('oai-authenticated-user-id');
      if(!signedIn)return new Response('Sign in required',{status:401,headers:securityHeaders});
      if(request.method!=='POST'||request.headers.get('Origin')!==url.origin)return new Response('Request not allowed',{status:403,headers:securityHeaders});
      if(request.headers.get('Content-Type')?.split(';')[0]!=='application/json')return new Response('JSON required',{status:415,headers:securityHeaders});
      const data=await request.text();
      if(data.length>4096)return new Response('Report too large',{status:413,headers:securityHeaders});
      let payload;try{payload=sanitizeDiagnostics(JSON.parse(data));}catch{}
      if(!payload)return new Response('Invalid report',{status:400,headers:securityHeaders});
      console.warn('ORBIT_GAME_DIAGNOSTICS',JSON.stringify(payload));
      return new Response(null,{status:204,headers:{...securityHeaders,'Cache-Control':'no-store'}});
    }
    // The Sites owner-only gate protects both HTTP and upgraded WebSockets.
    if(url.pathname==='/wisp/') {
      if(!engine&&env.ORBIT_ENGINE_ORIGIN)return new Response('Use the browsing engine',{status:404});
      if(!(engine?await engineContext(request,env):request.headers.get('oai-authenticated-user-id')))
        return new Response('Sign in required',{status:401,headers:securityHeaders});
      if(request.headers.get('Upgrade')?.toLowerCase()!=='websocket')
        return new Response('WebSocket connection required',{status:426,headers:securityHeaders});
      const origin=request.headers.get('Origin');
      if(!origin || origin!==url.origin)
        return new Response('Origin not allowed',{status:403,headers:securityHeaders});
      const target=new URL(env.WISP_UPSTREAM || DEFAULT_RELAY);
      if(target.protocol==='wss:')target.protocol='https:';
      if(target.protocol!=='https:')return new Response('Secure relay required',{status:503});
      // Only the configured upstream is reachable; browsing cannot choose one.
      const headers=new Headers({'Upgrade':'websocket'});
      if(env.WISP_TOKEN)headers.set('Authorization',`Bearer ${env.WISP_TOKEN}`);
      if(env.WISP_TOKEN)headers.set('Origin',url.origin);
      const protocol=request.headers.get('Sec-WebSocket-Protocol');
      if(protocol)headers.set('Sec-WebSocket-Protocol',protocol);
      // Retry the relay handshake only. No game requests or saves are replayed.
      for(let attempt=0;attempt<2;attempt++){
        try {
          const upstream=await fetch(target.href,{headers});
          if(upstream.status===101)return upstream;
          const retryable=[502,503,504].includes(upstream.status);
          console.warn('ORBIT_RELAY_UNAVAILABLE',JSON.stringify({status:upstream.status,attempt:attempt+1}));
          await upstream.body?.cancel();
          if(!retryable)break;
        } catch {
          console.warn('ORBIT_RELAY_UNAVAILABLE',JSON.stringify({networkError:true,attempt:attempt+1}));
        }
      }
      return new Response('Browsing connection unavailable',{status:502,headers:securityHeaders});
    }
    if(url.pathname==='/api/config')return Response.json({relay:'/wisp/',shared:!env.WISP_UPSTREAM,app:engine?env.ORBIT_APP_ORIGIN:undefined},{headers:{...securityHeaders,'Cache-Control':'no-store'}});
    if(!engine&&env.ORBIT_ENGINE_ORIGIN&&(url.pathname.startsWith('/browse/')||['/sw.js','/scram/scramjet.all.js'].includes(url.pathname)))return new Response('Browsing has moved to an isolated profile',{status:410});
    if(engine&&url.pathname.startsWith('/browse/')&&!await engineContext(request,env))return new Response('Sign in required',{status:401});
    if(!env.ASSETS)return new Response('Site assets unavailable',{status:503});
    const response=await env.ASSETS.fetch(request);
    const result=new Response(response.body,response);
    for(const [key,value] of Object.entries(securityHeaders))result.headers.set(key,value);
    if(engine){
      result.headers.set('Cross-Origin-Resource-Policy','cross-origin');
      if(url.pathname==='/'||url.pathname==='/index.html')result.headers.set('Content-Security-Policy',`frame-ancestors ${env.ORBIT_APP_ORIGIN}`);
    }else if(env.ORBIT_ENGINE_ORIGIN){
      result.headers.set('Permissions-Policy',`cross-origin-isolated=(self "${env.ORBIT_ENGINE_ORIGIN}")`);
      result.headers.set('Content-Security-Policy',`default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-src ${env.ORBIT_ENGINE_ORIGIN}; object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'`);
    }
    if(url.pathname==='/sw.js') {
      result.headers.set('Service-Worker-Allowed','/');
      result.headers.set('Cache-Control','no-store');
    }
    return result;
  }
};
