import {cookie,engineTicket} from './accounts.mjs';
const COOKIE='__Host-orbit-engine';
export async function engineContext(request,env,value=cookie(request,COOKIE),onFailure=()=>{}){
  const failed=report=>{onFailure(report);console.error('ORBIT_PROFILE_AUTH',JSON.stringify(report));return null;};
  if(typeof value!=='string'||value.length>2000||! /^[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}$/.test(value))return failed({stage:'ticket'});
  try{
    // The account server verifies the signature, audience, expiry and live
    // session before returning a profile. It is the single authority for
    // tickets; the engine does not need a second copy of its signing secret.
    const response=await fetch(env.ORBIT_APP_ORIGIN+'/api/engine-authorize',{method:'POST',headers:{'X-Orbit-Ticket':value},redirect:'manual',signal:AbortSignal.timeout(8000)});
    if(!response.ok)return failed({stage:'account',status:response.status});
    const context=await response.json();if(!/^[-\w]{43}$/.test(context.id)||!/^[-\w]{43}$/.test(context.key))return failed({stage:'context'});return context;
  }catch(error){console.error('ORBIT_PROFILE_CONNECTION',String(error.message).replace(/https?:\/\/\S+/g,'[endpoint]').slice(0,200));return failed({stage:'connection',code:error.name});}
}
export async function engineRoutes(request,env){
  const url=new URL(request.url),noStore={'Cache-Control':'no-store'};
  if(url.pathname==='/api/bootstrap'){
    if(request.method!=='POST'||request.headers.get('Origin')!==url.origin)return new Response('Request not allowed',{status:403});
    const value=engineTicket(request);let diagnostic;const context=await engineContext(request,env,value,report=>diagnostic=report);
    if(!context){const status=diagnostic?.stage==='ticket'||diagnostic?.stage==='account'&&diagnostic.status===401?401:503;return Response.json({error:status===401?'Your browsing connection needs to be renewed. Try again.':'Your browsing connection is temporarily unavailable. Try again.',diagnostic},{status,headers:noStore});}
    return Response.json(context,{headers:{...noStore,'Set-Cookie':`${COOKIE}=${value}; Path=/; HttpOnly; Secure; SameSite=None; Partitioned; Max-Age=600`}});
  }
  if(url.pathname==='/api/context'){
    let diagnostic;const context=await engineContext(request,env,cookie(request,COOKIE),report=>diagnostic=report);const status=context?200:diagnostic?.stage==='ticket'||diagnostic?.stage==='account'&&diagnostic.status===401?401:503;return Response.json(context||{error:status===401?'Browsing connection needs renewal':'Browsing connection unavailable'},{status,headers:noStore});
  }
  return null;
}
